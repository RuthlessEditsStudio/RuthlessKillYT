import { useState } from "react";
import { ArrowUpRight, Link as LinkIcon, Play, X } from "lucide-react";
import { BRAND, SHOWCASE } from "../config";
import { TikTokIcon } from "./icons";
import Reveal from "./Reveal";

/**
 * Drive iframe video shell
 *  - Locked 9:16 aspect ratio
 *  - One video "active" at a time
 *  - Iframe loads the Google Drive preview player when active
 */
function VideoShell({
  clip,
  isActive,
  onActivate,
  onClose,
}: {
  clip: (typeof SHOWCASE)[number];
  isActive: boolean;
  onActivate: () => void;
  onClose: () => void;
}) {
  // Once the iframe is live it swallows clicks, so the shell can't be a
  // <button> anymore — the player needs its own close control instead.
  if (isActive) {
    return (
      <div className="relative aspect-[9/16] w-full overflow-hidden rounded-2xl border border-white/10 bg-panel">
        <iframe
          src={clip.embedUrl}
          className="absolute inset-0 h-full w-full border-0"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowFullScreen
          title={clip.title}
        />
        <button
          type="button"
          onClick={onClose}
          aria-label={`Close ${clip.title}`}
          className="absolute top-2 right-2 z-10 flex h-8 w-8 items-center justify-center rounded-full bg-black/70 text-white/80 backdrop-blur-sm transition-colors hover:bg-black hover:text-white"
        >
          <X className="h-4 w-4" />
        </button>
      </div>
    );
  }

  return (
    <button
      type="button"
      onClick={onActivate}
      aria-label={`Play ${clip.title}`}
      className="group relative block aspect-[9/16] w-full cursor-pointer overflow-hidden rounded-2xl border border-white/10 bg-panel text-left focus:outline-none focus-visible:ring-2 focus-visible:ring-accent"
    >
      {(
        <span className="block">
          {/* Real frame pulled from the uploaded Drive video */}
          <div className="absolute inset-0 bg-gradient-to-br from-neutral-800 to-neutral-900" />
          <img
            src={clip.poster}
            alt={`${clip.title} — ${clip.style}`}
            loading="lazy"
            referrerPolicy="no-referrer"
            className="absolute inset-0 h-full w-full object-cover"
            onError={(e) => {
              // If the file isn't link-shared yet, fall back to the gradient
              e.currentTarget.style.display = "none";
            }}
          />
          <span className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/10 to-black/40" />
          <span className="absolute top-3 left-3 rounded-full border border-white/15 bg-black/50 px-2.5 py-1 text-[10px] font-semibold tracking-widest text-white/80 backdrop-blur-sm">
            {clip.style.toUpperCase()}
          </span>
          <span className="absolute inset-0 flex items-center justify-center">
            <span className="flex h-14 w-14 items-center justify-center rounded-full bg-accent shadow-[0_0_40px_rgba(255,49,49,0.4)] transition-transform group-hover:scale-110">
              <Play className="h-5 w-5 fill-white text-white" />
            </span>
          </span>
          <span className="absolute right-3 bottom-3 left-3 flex items-end justify-between">
            <span className="font-display text-sm font-semibold tracking-tight text-white">
              {clip.title}
            </span>
            <span className="text-[11px] font-medium text-white/60">
              {clip.length}
            </span>
          </span>
        </span>
      )}
    </button>
  );
}

export default function Showcase() {
  const [activeIndex, setActiveIndex] = useState<number | null>(null);

  return (
    <section id="work" className="scroll-mt-20 py-20 md:py-28">
      <div className="mx-auto max-w-6xl px-5">
        <Reveal>
          <p className="mb-3 flex items-center gap-2 text-xs font-semibold tracking-[0.2em] text-accent">
            <span className="h-px w-8 bg-accent" /> RECENT CUTS
          </p>
          <h2 className="font-display text-3xl font-bold tracking-tight md:text-5xl">
            The work
          </h2>
          <p className="mt-4 max-w-lg text-white/55">
            Vertical edits built to stop the scroll. Tap a shell to load and
            play the video from Google Drive.
          </p>
        </Reveal>

        <div className="mt-10 grid grid-cols-1 gap-3 md:grid-cols-3 md:gap-6">
          {SHOWCASE.map((clip, i) => (
            <Reveal key={clip.title} delay={i * 100}>
              <VideoShell
                clip={clip}
                isActive={activeIndex === i}
                onActivate={() => setActiveIndex(i)}
                onClose={() => setActiveIndex(null)}
              />
            </Reveal>
          ))}
        </div>

        <Reveal delay={150}>
          <div className="mt-8 flex flex-wrap items-center gap-3">
            <a
              href={BRAND.tiktokUrl}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-2 rounded-xl border border-white/15 px-4 py-3 text-sm font-medium text-white/70 transition-colors hover:border-white/30 hover:text-white"
            >
              <TikTokIcon className="h-4 w-4" />
              Fresh cuts weekly — {BRAND.tiktokHandle}
            </a>
            <a
              href={BRAND.websiteUrl}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-2 rounded-xl border border-accent/50 bg-accent/10 px-4 py-3 text-sm font-semibold text-accent transition-colors hover:bg-accent/20"
            >
              <LinkIcon className="h-4 w-4" />
              All my socials in one place
              <ArrowUpRight className="h-4 w-4" />
            </a>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
