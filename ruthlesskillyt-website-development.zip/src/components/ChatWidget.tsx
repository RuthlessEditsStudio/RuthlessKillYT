import { useEffect, useRef, useState } from "react";
import { ArrowRight, MessageCircle, Send, X } from "lucide-react";
import {
  GREETING,
  emptyMemory,
  respond,
  type ChatMemory,
} from "../chat/brain";
import { cn } from "../utils/cn";

type Msg = {
  id: number;
  from: "bot" | "user";
  text: string;
  chips?: string[];
  nav?: { label: string; target: string };
};

let uid = 0;

/** Renders **bold** segments without dangerouslySetInnerHTML. */
function RichText({ text }: { text: string }) {
  return (
    <>
      {text.split("\n").map((line, li) => (
        <span key={li} className="block min-h-[1px]">
          {line.split(/(\*\*[^*]+\*\*)/g).map((part, pi) =>
            part.startsWith("**") && part.endsWith("**") ? (
              <strong key={pi} className="font-semibold text-white">
                {part.slice(2, -2)}
              </strong>
            ) : (
              <span key={pi}>{part}</span>
            )
          )}
        </span>
      ))}
    </>
  );
}

export default function ChatWidget() {
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState("");
  const [typing, setTyping] = useState(false);
  const [nudge, setNudge] = useState(false);
  const [memory, setMemory] = useState<ChatMemory>(emptyMemory());
  const [msgs, setMsgs] = useState<Msg[]>([
    { id: uid++, from: "bot", text: GREETING.text, chips: GREETING.chips },
  ]);

  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const timers = useRef<number[]>([]);

  // Clean up any pending timers on unmount
  useEffect(
    () => () => {
      timers.current.forEach(clearTimeout);
    },
    []
  );

  // Keep the transcript pinned to the newest message
  useEffect(() => {
    scrollRef.current?.scrollTo({
      top: scrollRef.current.scrollHeight,
      behavior: "smooth",
    });
  }, [msgs, typing]);

  // Gentle one-time nudge so people notice the bot exists
  useEffect(() => {
    const t = window.setTimeout(() => setNudge(true), 12000);
    timers.current.push(t);
    return () => clearTimeout(t);
  }, []);

  useEffect(() => {
    if (open) {
      setNudge(false);
      const t = window.setTimeout(() => inputRef.current?.focus(), 250);
      timers.current.push(t);
    }
  }, [open]);

  // Freeze the page behind the chat. Without this, scrolling past the end of
  // the transcript chains through to the landing page underneath.
  useEffect(() => {
    if (!open) return;

    const { body, documentElement: html } = document;
    const scrollY = window.scrollY;
    // Compensate for the vanishing scrollbar so the layout doesn't jump
    const gap = window.innerWidth - html.clientWidth;

    const prev = {
      position: body.style.position,
      top: body.style.top,
      width: body.style.width,
      overflow: body.style.overflow,
      paddingRight: body.style.paddingRight,
    };

    body.style.position = "fixed";
    body.style.top = `-${scrollY}px`;
    body.style.width = "100%";
    body.style.overflow = "hidden";
    if (gap > 0) body.style.paddingRight = `${gap}px`;

    return () => {
      body.style.position = prev.position;
      body.style.top = prev.top;
      body.style.width = prev.width;
      body.style.overflow = prev.overflow;
      body.style.paddingRight = prev.paddingRight;
      window.scrollTo(0, scrollY);
    };
  }, [open]);

  const push = (m: Omit<Msg, "id">) =>
    setMsgs((cur) => [...cur, { ...m, id: uid++ }]);

  const send = (raw: string) => {
    const text = raw.trim();
    if (!text || typing) return;

    push({ from: "user", text });
    setInput("");
    setTyping(true);

    const { reply, memory: nextMem } = respond(text, memory);
    setMemory(nextMem);

    // Delay scales with reply length so it reads like someone typing
    const delay = Math.min(1400, 450 + reply.text.length * 6);

    const t = window.setTimeout(() => {
      setTyping(false);
      push({
        from: "bot",
        text: reply.text,
        chips: reply.chips,
        nav: reply.nav,
      });
    }, delay);
    timers.current.push(t);
  };

  // Only ever called from an explicit tap — the page never moves on its own,
  // so nobody gets yanked away mid-sentence. Closing first releases the
  // body-scroll lock; the delay lets that unwind before we scroll.
  const goTo = (id: string) => {
    if (!document.getElementById(id)) return;
    setOpen(false);
    const t = window.setTimeout(() => {
      document
        .getElementById(id)
        ?.scrollIntoView({ behavior: "smooth", block: "start" });
    }, 320);
    timers.current.push(t);
  };

  const lastChips: string[] | undefined = (() => {
    const last = msgs[msgs.length - 1];
    return last?.from === "bot" && !typing ? last.chips : undefined;
  })();

  return (
    <>
      {/* Launcher */}
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-label={open ? "Close chat" : "Open chat"}
        className={cn(
          "fixed right-4 bottom-4 z-[90] flex h-14 w-14 items-center justify-center rounded-full bg-accent shadow-[0_8px_30px_rgba(255,49,49,0.35)] transition-transform hover:scale-105 active:scale-95 sm:right-6 sm:bottom-6",
          open && "scale-0 opacity-0"
        )}
      >
        <MessageCircle className="h-6 w-6 text-white" />
        {nudge && !open && (
          <span className="absolute -top-0.5 -right-0.5 flex h-3.5 w-3.5">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-white opacity-60" />
            <span className="relative inline-flex h-3.5 w-3.5 rounded-full border-2 border-ink bg-white" />
          </span>
        )}
      </button>

      {/* Nudge bubble */}
      {nudge && !open && (
        <button
          type="button"
          onClick={() => setOpen(true)}
          className="fixed right-20 bottom-6 z-[90] hidden max-w-[220px] rounded-2xl rounded-br-sm border border-white/10 bg-panel px-4 py-3 text-left text-xs leading-relaxed text-white/70 shadow-xl sm:block sm:bottom-8"
        >
          Questions about pricing or turnaround? Ask away.
        </button>
      )}

      {/* Panel */}
      <div
        className={cn(
          "fixed z-[120] flex flex-col overflow-hidden border border-white/10 bg-panel shadow-2xl transition-all duration-300",
          "inset-x-0 bottom-0 h-[80vh] max-h-[calc(100dvh-4.5rem)] rounded-t-3xl",
          "sm:inset-auto sm:right-6 sm:bottom-6 sm:h-[560px] sm:max-h-[calc(100dvh-6rem)] sm:w-[380px] sm:rounded-3xl",
          open
            ? "pointer-events-auto translate-y-0 opacity-100"
            : "pointer-events-none translate-y-6 opacity-0"
        )}
        role="dialog"
        aria-label="Chat with RuthlessKillYT"
      >
        {/* Header */}
        <div className="flex shrink-0 items-center justify-between border-b border-white/10 px-4 py-3.5">
          <div className="flex items-center gap-3">
            <span className="relative flex h-9 w-9 items-center justify-center rounded-full bg-accent font-display text-xs font-bold text-white">
              RK
              <span className="absolute -right-0.5 -bottom-0.5 h-3 w-3 rounded-full border-2 border-panel bg-emerald-400" />
            </span>
            <div>
              <p className="font-display text-sm font-bold tracking-tight">
                RuthlessKillYT
              </p>
              <p className="text-[11px] text-white/40">
                Assistant · replies instantly
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setOpen(false)}
            aria-label="Close chat"
            className="rounded-lg p-2 text-white/50 transition-colors hover:bg-white/5 hover:text-white"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Transcript */}
        <div
          ref={scrollRef}
          className="min-h-0 flex-1 space-y-3 overflow-y-auto overscroll-contain px-4 py-4"
        >
          {msgs.map((m) => (
            <div
              key={m.id}
              className={cn(
                "flex",
                m.from === "user" ? "justify-end" : "justify-start"
              )}
            >
              <div className={cn("max-w-[85%]", m.from === "user" && "flex justify-end")}>
                <div
                  className={cn(
                    "rounded-2xl px-3.5 py-2.5 text-sm leading-relaxed",
                    m.from === "user"
                      ? "rounded-br-sm bg-accent text-white"
                      : "rounded-bl-sm bg-panel-2 text-white/75"
                  )}
                >
                  <RichText text={m.text} />
                </div>

                {/* Navigation is always a choice, never automatic */}
                {m.nav && (
                  <button
                    type="button"
                    onClick={() => goTo(m.nav!.target)}
                    className="mt-2 flex items-center gap-1.5 rounded-xl border border-accent/40 bg-accent/10 px-3.5 py-2 text-xs font-semibold text-accent transition-colors hover:bg-accent/20"
                  >
                    {m.nav.label}
                    <ArrowRight className="h-3.5 w-3.5" />
                  </button>
                )}
              </div>
            </div>
          ))}

          {typing && (
            <div className="flex justify-start">
              <div className="flex gap-1 rounded-2xl rounded-bl-sm bg-panel-2 px-4 py-3.5">
                {[0, 150, 300].map((d) => (
                  <span
                    key={d}
                    className="h-1.5 w-1.5 animate-bounce rounded-full bg-white/40"
                    style={{ animationDelay: `${d}ms` }}
                  />
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Quick replies */}
        {lastChips && lastChips.length > 0 && (
          <div className="flex shrink-0 flex-wrap gap-2 px-4 pb-2">
            {lastChips.map((c) => (
              <button
                key={c}
                type="button"
                onClick={() => send(c)}
                className="rounded-full border border-white/15 px-3 py-1.5 text-xs font-medium text-white/65 transition-colors hover:border-accent/60 hover:text-white"
              >
                {c}
              </button>
            ))}
          </div>
        )}

        {/* Composer */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            send(input);
          }}
          className="flex shrink-0 items-center gap-2 border-t border-white/10 p-3"
        >
          <input
            ref={inputRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask about pricing, turnaround…"
            className="min-w-0 flex-1 rounded-xl border border-white/10 bg-panel-2 px-3.5 py-2.5 text-sm text-white placeholder:text-white/30 focus:border-accent/60 focus:outline-none"
          />
          <button
            type="submit"
            disabled={!input.trim() || typing}
            aria-label="Send message"
            className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-accent text-white transition-transform hover:scale-105 active:scale-95 disabled:cursor-not-allowed disabled:opacity-40"
          >
            <Send className="h-4 w-4" />
          </button>
        </form>
      </div>
    </>
  );
}
