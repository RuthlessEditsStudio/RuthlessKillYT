import { ArrowDown, Play } from "lucide-react";
import { BRAND, FLAT_RATE, HALF_MIN_RATE } from "../config";
import Reveal from "./Reveal";

const STATS = [
  { value: "50+", label: "vids delivered" },
  {
    value: `$${FLAT_RATE.toFixed(2)}/min`,
    label: `flat — $${HALF_MIN_RATE.toFixed(2)} per 30s`,
  },
  { value: "100%", label: "vertical" },
];

export default function Hero() {
  return (
    <section id="top" className="relative overflow-hidden pt-32 pb-16 md:pt-44 md:pb-24">
      {/* backdrop */}
      <div className="bg-grid absolute inset-0 [mask-image:radial-gradient(ellipse_75%_65%_at_50%_35%,black,transparent)]" />
      <div className="glow-accent absolute -top-40 left-1/2 h-[560px] w-[900px] -translate-x-1/2" />

      <div className="relative mx-auto grid max-w-6xl items-center gap-14 px-5 lg:grid-cols-[1.15fr_0.85fr]">
        <div>
          <Reveal>
            <p className="mb-5 inline-flex items-center gap-2 rounded-full border border-white/10 bg-panel px-3.5 py-1.5 text-xs font-medium tracking-wide text-white/60">
              <span className="h-1.5 w-1.5 rounded-full bg-accent" />
              VERTICAL VIDEO EDITING — TIKTOK FIRST
            </p>
          </Reveal>

          <Reveal delay={80}>
            <h1 className="font-display text-5xl leading-[0.95] font-bold tracking-tight md:text-7xl">
              Your clips,
              <br />
              edited <span className="text-accent">ruthless.</span>
            </h1>
          </Reveal>

          <Reveal delay={160}>
            <p className="mt-6 max-w-md text-base leading-relaxed text-white/55 md:text-lg">
              Raw footage in, scroll-stopping 9:16 edits out. One flat rate —
              ${FLAT_RATE.toFixed(2)} a finished minute, ${HALF_MIN_RATE.toFixed(2)}{" "}
              for a 30-second cut. CashApp only, zero fluff.
            </p>
          </Reveal>

          <Reveal delay={240}>
            <div className="mt-8 flex flex-wrap items-center gap-3">
              <a
                href="#work"
                className="inline-flex items-center gap-2 rounded-xl bg-accent px-6 py-3.5 text-sm font-semibold text-white transition-transform hover:scale-[1.02] active:scale-[0.98]"
              >
                See the work <ArrowDown className="h-4 w-4" />
              </a>
              <a
                href="#calculator"
                className="inline-flex items-center gap-2 rounded-xl border border-white/15 px-6 py-3.5 text-sm font-semibold text-white/80 transition-colors hover:border-white/30 hover:text-white"
              >
                Price your video
              </a>
            </div>
          </Reveal>

          <Reveal delay={320}>
            <dl className="mt-12 grid grid-cols-3 gap-6 border-t border-white/10 pt-8">
              {STATS.map((s) => (
                <div key={s.label}>
                  <dt className="sr-only">{s.label}</dt>
                  <dd className="font-display text-2xl font-bold tracking-tight md:text-3xl">
                    {s.value}
                  </dd>
                  <dd className="mt-1 text-xs text-white/45 md:text-sm">
                    {s.label}
                  </dd>
                </div>
              ))}
            </dl>
          </Reveal>
        </div>

        {/* CSS-only 9:16 shell — no media weight, just the vibe */}
        <Reveal delay={200} className="hidden lg:block">
          <div className="relative mx-auto max-w-[280px]">
            <div className="absolute inset-0 translate-x-4 translate-y-4 rotate-3 rounded-3xl border border-accent/40" />
            <div className="relative flex aspect-[9/16] flex-col justify-between overflow-hidden rounded-3xl border border-white/10 bg-panel p-5">
              <div className="glow-accent absolute -top-20 -right-20 h-64 w-64" />
              <div className="relative flex items-center justify-between text-[10px] font-semibold tracking-widest text-white/40">
                <span>9:16</span>
                <span>1080×1920</span>
              </div>
              <div className="relative flex flex-col items-center gap-4">
                <span className="flex h-16 w-16 items-center justify-center rounded-full bg-accent shadow-[0_0_50px_rgba(255,49,49,0.45)]">
                  <Play className="h-6 w-6 fill-white text-white" />
                </span>
                <span className="font-display text-sm font-semibold tracking-wide text-white/70">
                  TIKTOK-READY
                </span>
              </div>
              <div className="relative">
                <div className="h-1 w-full overflow-hidden rounded-full bg-white/10">
                  <div className="h-full w-2/3 rounded-full bg-accent" />
                </div>
                <p className="mt-3 text-[10px] tracking-widest text-white/35">
                  {BRAND.cashappTag} · CASHAPP ONLY
                </p>
              </div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
