import { BRAND } from "../config";
import { BrandMark, TikTokIcon } from "./icons";

export default function Footer() {
  return (
    <footer className="border-t border-white/5 py-10">
      <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-5 px-5">
        <div className="flex items-center gap-3">
          <BrandMark className="h-7 w-7 text-[11px]" />
          <div>
            <p className="font-display text-sm font-bold tracking-tight">
              {BRAND.name}
            </p>
            <p className="text-xs text-white/35">
              © {new Date().getFullYear()} — Payment via {BRAND.cashappTag} after scope is agreed upon
            </p>
          </div>
        </div>
        <div className="flex items-center gap-6">
          <a
            href={BRAND.tiktokUrl}
            target="_blank"
            rel="noreferrer"
            className="flex items-center gap-2 text-sm text-white/50 transition-colors hover:text-white"
          >
            <TikTokIcon className="h-4 w-4" />
            {BRAND.tiktokHandle}
          </a>
          <a
            href={BRAND.websiteUrl}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-2 rounded-xl border border-accent/50 bg-accent/10 px-4 py-2.5 text-sm font-semibold text-accent transition-colors hover:bg-accent/20"
          >
            All my socials
          </a>
        </div>
      </div>
    </footer>
  );
}
