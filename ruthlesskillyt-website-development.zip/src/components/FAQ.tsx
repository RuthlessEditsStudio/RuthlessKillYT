import { useState } from "react";
import { ChevronDown } from "lucide-react";
import { cn } from "../utils/cn";
import Reveal from "./Reveal";

const FAQS = [
  {
    q: "How does payment work?",
    a: "CashApp only — that's the whole list. We lock the scope, I send my tag, and editing starts the moment it clears.",
  },
  {
    q: "What's the turnaround?",
    a: "Standard turnaround is 3–7 days from the time payment clears and I have your footage. In a crunch? Add Rush 24–72h in the calculator and you jump the queue.",
  },
  {
    q: "What kind of videos do you edit?",
    a: "Vertical first: TikToks, Reels, Shorts. Gaming clips, vlogs, podcast cuts — whatever needs to stop the scroll.",
  },
  {
    q: "How do I send my footage?",
    a: "Drop a Drive or WeTransfer link in the contact form. Big files, messy folders — I'll take it from there.",
  },
];

export default function FAQ() {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <section id="faq" className="scroll-mt-20 border-t border-white/5 py-20 md:py-28">
      <div className="mx-auto max-w-3xl px-5">
        <Reveal>
          <p className="mb-3 flex items-center gap-2 text-xs font-semibold tracking-[0.2em] text-accent">
            <span className="h-px w-8 bg-accent" /> FAQ
          </p>
          <h2 className="font-display text-3xl font-bold tracking-tight md:text-5xl">
            Quick answers
          </h2>
        </Reveal>

        <Reveal delay={120}>
          <div className="mt-10 border-t border-white/10">
            {FAQS.map((f, i) => {
              const isOpen = open === i;
              return (
                <div key={f.q} className="border-b border-white/10">
                  <button
                    type="button"
                    onClick={() => setOpen(isOpen ? null : i)}
                    aria-expanded={isOpen}
                    className="flex w-full items-center justify-between gap-4 py-5 text-left"
                  >
                    <span className="font-display text-[15px] font-semibold tracking-tight md:text-base">
                      {f.q}
                    </span>
                    <ChevronDown
                      className={cn(
                        "h-4 w-4 shrink-0 text-white/40 transition-transform duration-300",
                        isOpen && "rotate-180 text-accent"
                      )}
                    />
                  </button>
                  <div
                    className={cn(
                      "grid transition-all duration-300 ease-out",
                      isOpen
                        ? "grid-rows-[1fr] opacity-100"
                        : "grid-rows-[0fr] opacity-0"
                    )}
                  >
                    <div className="overflow-hidden">
                      <p className="pb-5 text-sm leading-relaxed text-white/55">
                        {f.a}
                      </p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </Reveal>
      </div>
    </section>
  );
}
