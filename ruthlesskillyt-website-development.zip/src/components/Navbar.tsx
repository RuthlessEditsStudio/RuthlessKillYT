import { useState } from "react";
import { Link as LinkIcon, Menu, X } from "lucide-react";
import { BRAND } from "../config";
import { BrandMark, TikTokIcon } from "./icons";

export default function Navbar({
  termsAccepted = false,
}: {
  termsAccepted?: boolean;
}) {
  const [open, setOpen] = useState(false);

  // The contact section doesn't exist until the terms are agreed to,
  // so send people to the calculator instead of a dead anchor.
  const LINKS = [
    { label: "Work", href: "#work" },
    { label: "Calculator", href: "#calculator" },
    { label: "FAQ", href: "#faq" },
    { label: "Contact", href: termsAccepted ? "#contact" : "#calculator" },
  ];

  return (
    <header className="fixed inset-x-0 top-0 z-50 border-b border-white/5 bg-ink/80 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-5">
        <a href="#top" className="flex items-center gap-3">
          <BrandMark className="h-8 w-8 text-sm" />
          <span className="font-display text-[15px] font-bold tracking-tight">
            {BRAND.name}
          </span>
        </a>

        <nav className="hidden items-center gap-7 md:flex">
          {LINKS.map((l) => (
            <a
              key={l.label}
              href={l.href}
              className="text-sm text-white/60 transition-colors hover:text-white"
            >
              {l.label}
            </a>
          ))}
          <a
            href={BRAND.tiktokUrl}
            target="_blank"
            rel="noreferrer"
            aria-label="TikTok"
            className="text-white/60 transition-colors hover:text-white"
          >
            <TikTokIcon className="h-[18px] w-[18px]" />
          </a>
          {/* Socials hub — highlighted so it reads as a real destination */}
          <a
            href={BRAND.websiteUrl}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-1.5 rounded-full border border-accent/50 bg-accent/10 px-3.5 py-1.5 text-xs font-semibold text-accent transition-colors hover:bg-accent/20"
          >
            <LinkIcon className="h-3.5 w-3.5" />
            All my socials
          </a>
        </nav>

        <button
          className="text-white/70 md:hidden"
          onClick={() => setOpen((v) => !v)}
          aria-label="Toggle menu"
        >
          {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </div>

      {open && (
        <nav className="border-t border-white/5 bg-ink px-5 py-4 md:hidden">
          <div className="flex flex-col gap-4">
            {LINKS.map((l) => (
              <a
                key={l.label}
                href={l.href}
                onClick={() => setOpen(false)}
                className="text-sm text-white/70"
              >
                {l.label}
              </a>
            ))}
            <a
              href={BRAND.tiktokUrl}
              target="_blank"
              rel="noreferrer"
              className="flex items-center gap-2 text-sm text-white/70"
            >
              <TikTokIcon className="h-4 w-4" /> {BRAND.tiktokHandle}
            </a>
            <a
              href={BRAND.websiteUrl}
              target="_blank"
              rel="noreferrer"
              onClick={() => setOpen(false)}
              className="mt-1 inline-flex items-center justify-center gap-2 rounded-xl border border-accent/50 bg-accent/10 px-4 py-3 text-sm font-semibold text-accent"
            >
              <LinkIcon className="h-4 w-4" />
              All my socials
            </a>
          </div>
        </nav>
      )}
    </header>
  );
}
