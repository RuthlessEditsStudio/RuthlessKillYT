import { useEffect } from "react";
import { Check, X } from "lucide-react";
import { BRAND } from "../config";

/**
 * Full fine print, shown in a modal so it never adds scroll to the page.
 * Closes on backdrop click, X button, or Escape.
 */
export default function TermsModal({
  open,
  onClose,
  onAccept,
}: {
  open: boolean;
  onClose: () => void;
  onAccept: () => void;
}) {
  // Escape to close + lock background scroll while open
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = prev;
    };
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-[100] flex items-end justify-center bg-black/80 p-0 backdrop-blur-sm sm:items-center sm:p-5"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-label="Terms, revisions and usage rights"
    >
      <div
        className="relative flex max-h-[88vh] w-full max-w-2xl flex-col overflow-hidden rounded-t-3xl border border-white/10 bg-panel sm:rounded-3xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex shrink-0 items-start justify-between gap-4 border-b border-white/10 px-6 py-5">
          <div>
            <p className="text-xs font-semibold tracking-[0.2em] text-accent">
              THE FINE PRINT
            </p>
            <h3 className="mt-1.5 font-display text-2xl font-bold tracking-tight">
              Terms, revisions & usage
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close terms"
            className="shrink-0 rounded-lg border border-white/10 p-2 text-white/60 transition-colors hover:border-white/25 hover:text-white"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Scrollable body */}
        <div className="min-h-0 flex-1 space-y-7 overflow-y-auto px-6 py-6 text-sm leading-relaxed text-white/65">
          <Section title="How it works">
            <ol className="list-decimal space-y-1.5 pl-4 marker:text-accent">
              <li>You send your footage and tell me what you want.</li>
              <li>We agree on the video type, length, count and final price.</li>
              <li>
                You send payment to{" "}
                <span className="font-semibold text-white">
                  {BRAND.cashappTag}
                </span>{" "}
                — <span className="text-white/80">only after</span> the scope is
                agreed on.
              </li>
              <li>I edit and deliver in 3–7 days (24–72 hours with Rush).</li>
              <li>You get one light revision per video, free.</li>
            </ol>
          </Section>

          <Section title="Revisions">
            <p>
              Every video in your order includes{" "}
              <span className="font-semibold text-white">
                one free light revision
              </span>{" "}
              — small stuff like a caption typo, a trim, a music swap, or a
              color tweak.
            </p>
            <p className="mt-2">
              After that, it's{" "}
              <span className="font-semibold text-white">
                $3 per moderate revision
              </span>
              . A moderate revision means re-cutting sections, restructuring
              pacing, or reworking a chunk of the edit.
            </p>
            <p className="mt-2">
              A full re-edit, a new concept, or a change to the agreed length or
              style counts as a{" "}
              <span className="font-semibold text-white">new order</span> at the
              normal rate. Revision requests should come within 7 days of
              delivery.
            </p>
          </Section>

          <Section title="Payment">
            <p>
              CashApp only —{" "}
              <span className="font-semibold text-white">
                {BRAND.cashappTag}
              </span>
              . Payment is sent after we agree on the video type and scope, and
              work begins once it clears.
            </p>
            <p className="mt-2">
              Prices from the calculator are an{" "}
              <span className="font-semibold text-white">estimate</span>, not a
              binding quote. The final price is whatever we agree on in writing
              before payment. Because every edit is custom work, payments are
              generally non-refundable once editing has started — but if
              something goes wrong on my end, talk to me and we'll make it
              right.
            </p>
          </Section>

          <Section title="Your footage & your rights">
            <p>
              You keep{" "}
              <span className="font-semibold text-white">
                full ownership of your footage and the finished edit
              </span>
              . Post it, monetize it, run ads on it, put it wherever you want —
              it's yours, no royalties, no strings.
            </p>
            <p className="mt-2">
              By sending me footage, you confirm you have the right to use it,
              including any music, clips, logos, or people in it. You're
              responsible for clearances, copyright and platform strikes on
              material you provide.
            </p>
          </Section>

          <Section title="My rights">
            <p>
              I may feature finished cuts in my portfolio, on my TikTok, or on
              this site as examples of my work.{" "}
              <span className="font-semibold text-white">
                Just tell me if you'd rather I didn't
              </span>{" "}
              — say the word before or after delivery and I'll keep it private.
            </p>
          </Section>

          <Section title="Turnaround & delivery">
            <p>
              Standard turnaround is{" "}
              <span className="font-semibold text-white">3 to 7 days</span>.
              Adding{" "}
              <span className="font-semibold text-white">Rush 24–72h</span>{" "}
              moves you to the front of the queue and delivers within 24 to 72
              hours. These are estimates, not guarantees — timelines start when
              payment clears and I have all your footage, not before. Bigger
              orders and heavy revision rounds can push the longer end of the
              range.
            </p>
            <p className="mt-2">
              Delivery is a download link. Keep your own backups; I don't
              guarantee I'll store project files or footage after delivery.
            </p>
          </Section>

          <Section title="What I won't edit">
            <p>
              I turn down anything illegal, hateful, sexually explicit,
              targeted harassment, or content designed to deceive or defraud
              people. If a project turns out to be one of those, I'll cancel it
              and refund any unstarted work.
            </p>
          </Section>

          <Section title="Liability">
            <p>
              I deliver editing services — I can't guarantee views, followers,
              revenue, or how any platform treats your content. My total
              liability for any issue is limited to what you paid me for that
              order.
            </p>
            <p className="mt-2">
              These terms can change over time; the version on this page at the
              time of your order is the one that applies. This isn't a legal
              contract drafted by a lawyer — it's a plain-English rundown of how
              I work.
            </p>
          </Section>
        </div>

        {/* Footer — must agree to unlock the contact form */}
        <div className="shrink-0 border-t border-white/10 px-6 py-4">
          <button
            type="button"
            onClick={onAccept}
            className="flex w-full items-center justify-center gap-2 rounded-xl bg-accent px-6 py-3.5 text-sm font-semibold text-white transition-transform hover:scale-[1.01] active:scale-[0.99]"
          >
            <Check className="h-4 w-4" />
            I agree — continue to the form
          </button>
          <button
            type="button"
            onClick={onClose}
            className="mt-2 w-full rounded-xl px-6 py-2.5 text-xs font-medium text-white/40 transition-colors hover:text-white/70"
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
}

function Section({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}) {
  return (
    <div>
      <h4 className="mb-2 font-display text-sm font-bold tracking-tight text-white">
        {title}
      </h4>
      {children}
    </div>
  );
}
