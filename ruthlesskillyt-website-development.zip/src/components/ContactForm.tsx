import { useEffect, useState, type FormEvent } from "react";
import emailjs from "@emailjs/browser";
import {
  AlertTriangle,
  CheckCircle2,
  Clock,
  Loader2,
  MessageCircle,
  Paperclip,
  Send,
  Scissors,
} from "lucide-react";
import {
  ADD_ONS,
  BRAND,
  EMAILJS,
  EMAILJS_READY,
  formatMinutes,
  formatMoney,
  type EstimateState,
} from "../config";
import { cn } from "../utils/cn";
import Reveal from "./Reveal";
import {
  isOnCooldown,
  getRemainingMs,
  formatRemaining,
  recordSubmission,
} from "../utils/cooldown";

type Mode = "edit" | "talk";
type Status = "idle" | "sending" | "success" | "error" | "unconfigured";

const inputCls =
  "w-full rounded-xl border border-white/10 bg-panel-2 px-4 py-3 text-sm text-white placeholder:text-white/30 focus:border-accent/60 focus:outline-none focus:ring-1 focus:ring-accent/40 transition-colors disabled:cursor-not-allowed disabled:opacity-40";

export default function ContactForm({
  estimate,
  termsAccepted,
  onRequireTerms,
}: {
  estimate: EstimateState;
  termsAccepted: boolean;
  /** Revokes agreement so the form re-locks and they must agree again. */
  onRequireTerms: () => void;
}) {
  const [mode, setMode] = useState<Mode>("edit");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [cashappTag, setCashappTag] = useState("");
  const [notes, setNotes] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [status, setStatus] = useState<Status>("idle");
  const [remainingMs, setRemainingMs] = useState(getRemainingMs());

  // Live countdown while on cooldown. The moment the 24h lockout expires,
  // agreement is revoked — they must accept the terms again before the
  // form comes back, even if they never reloaded the page.
  //
  // Re-runs when `status` changes so the timer also starts immediately after
  // a successful send (previously it only ran on mount, so a fresh cooldown
  // never began ticking).
  useEffect(() => {
    if (!isOnCooldown()) {
      setRemainingMs(0);
      return;
    }
    setRemainingMs(getRemainingMs());
    const timer = setInterval(() => {
      const left = getRemainingMs();
      setRemainingMs(left);
      if (left <= 0) {
        clearInterval(timer);
        onRequireTerms();
      }
    }, 1000);
    return () => clearInterval(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [status]);

  const addOnNames = ADD_ONS.filter((a) => estimate.addOns.includes(a.id)).map(
    (a) => a.name
  );

  const buildParams = (): Record<string, string> => {
    const params: Record<string, string> = {
      from_name: name.trim(),
      from_email: email.trim(),
      reply_to: email.trim(),
      mode: mode === "edit" ? "Edit Request" : "Just Want To Talk",
      cashapp_tag: cashappTag.trim() || "—",
      notes: notes.trim(),
      // Always include edit fields so the template never sees missing variables
      video_length: mode === "edit" ? formatMinutes(estimate.minutes) : "—",
      video_count: mode === "edit" ? String(estimate.count) : "—",
      add_ons: mode === "edit" ? (addOnNames.length ? addOnNames.join(", ") : "None") : "—",
      estimate: mode === "edit" ? formatMoney(estimate.total) : "—",
    };
    return params;
  };

  const validate = (): boolean => {
    const next: Record<string, string> = {};
    if (name.trim().length < 2) next.name = "Your name, at least.";
    if (!/^\S+@\S+\.\S+$/.test(email.trim()))
      next.email = "That email doesn't look right.";
    if (notes.trim().length < 10)
      next.notes =
        mode === "edit"
          ? "Give me a line or two — style, footage link, deadline."
          : "Say a little more than that.";
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!validate()) return;
    if (isOnCooldown()) return; // cooldown guard

    if (!EMAILJS_READY) {
      setStatus("unconfigured");
      console.info(
        "[RuthlessKillYT] EmailJS keys missing — these params would send:",
        buildParams()
      );
      return;
    }

    setStatus("sending");
    try {
      // Race against a timeout so a hung network can't leave the button
      // stuck on "Sending…" forever.
      await Promise.race([
        emailjs.send(EMAILJS.serviceId, EMAILJS.templateId, buildParams(), {
          publicKey: EMAILJS.publicKey,
        }),
        new Promise((_, reject) =>
          setTimeout(() => reject(new Error("Request timed out")), 20000)
        ),
      ]);
      recordSubmission();
      setStatus("success");
    } catch (err) {
      console.error("EmailJS send failed:", err);
      setStatus("error");
    }
  };

  const reset = () => {
    setStatus("idle");
    setName("");
    setEmail("");
    setCashappTag("");
    setNotes("");
    setErrors({});
    // Starting over means agreeing to the terms again. That unmounts this
    // whole section, so send them back to the calculator instead of leaving
    // them staring at the FAQ wondering where the form went.
    onRequireTerms();
    requestAnimationFrame(() => {
      document
        .getElementById("calculator")
        ?.scrollIntoView({ behavior: "smooth", block: "start" });
    });
  };

  const onCooldown = isOnCooldown();

  // The whole contact section stays hidden until the terms are agreed to
  // in the calculator. Keeps the page short and the agreement mandatory.
  if (!termsAccepted) return null;

  return (
    <section
      id="contact"
      className="scroll-mt-20 border-t border-white/5 py-20 md:py-28"
    >
      <div className="mx-auto max-w-2xl px-5">
        <Reveal>
          <p className="mb-3 flex items-center gap-2 text-xs font-semibold tracking-[0.2em] text-accent">
            <span className="h-px w-8 bg-accent" /> CONTACT
          </p>
          <h2 className="font-display text-3xl font-bold tracking-tight md:text-5xl">
            Let's talk
          </h2>
          <p className="mt-4 text-white/55">
            Edits, questions, or just want to talk — same form, straight to my
            inbox.
          </p>
        </Reveal>

        {/* Cooldown warning — shown when user must wait */}
        {onCooldown && status !== "success" ? (
          <Reveal delay={120}>
            <div className="mt-10 rounded-3xl border border-amber-400/30 bg-amber-400/10 p-6 text-center">
              <Clock className="mx-auto h-10 w-10 text-amber-400" />
              <p className="mt-4 font-display text-xl font-bold tracking-tight text-amber-100/90">
                One request per 24 hours
              </p>
              <p className="mt-2 text-sm text-amber-100/70">
                Please wait {formatRemaining(remainingMs)} before sending another.
              </p>
            </div>
          </Reveal>
        ) : null}

        <Reveal delay={120}>
          <div className="mt-10 rounded-3xl border border-white/10 bg-panel p-6 md:p-8">
            {status === "success" ? (
              <div className="flex flex-col items-center py-10 text-center">
                <CheckCircle2 className="h-12 w-12 text-accent" />
                <h3 className="mt-5 font-display text-2xl font-bold tracking-tight">
                  Sent. Talk soon.
                </h3>
                <p className="mt-2 max-w-sm text-sm leading-relaxed text-white/55">
                  Your {mode === "edit" ? "estimate and notes" : "message"} just
                  landed in my inbox. I reply within 24 hours — usually way
                  faster.
                </p>
                <p className="mt-4 text-xs text-white/35">
                  One request per device every 24 hours.
                </p>
                <button
                  type="button"
                  onClick={reset}
                  className="mt-7 rounded-xl border border-white/15 px-5 py-3 text-sm font-semibold text-white/80 transition-colors hover:border-white/30 hover:text-white"
                >
                  Send another
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} noValidate>
                {/* Mode toggle */}
                <div className="grid grid-cols-2 gap-1 rounded-2xl border border-white/10 bg-panel-2 p-1">
                  {(
                    [
                      { id: "edit", label: "I want an edit", icon: Scissors },
                      { id: "talk", label: "Just want to talk", icon: MessageCircle },
                    ] as const
                  ).map((m) => (
                    <button
                      key={m.id}
                      type="button"
                      onClick={() => {
                        setMode(m.id);
                        setErrors({});
                      }}
                      disabled={onCooldown}
                      className={cn(
                        "flex items-center justify-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold transition-colors disabled:opacity-40",
                        mode === m.id
                          ? "bg-accent text-white"
                          : "text-white/50 hover:text-white"
                      )}
                    >
                      <m.icon className="h-4 w-4" />
                      {m.label}
                    </button>
                  ))}
                </div>

                {/* Estimate attachment — edit mode only, always live from the calculator */}
                {mode === "edit" && (
                  <div className="mt-5 rounded-2xl border border-dashed border-white/15 bg-panel-2 p-4">
                    <p className="flex items-center gap-2 text-xs font-semibold tracking-wide text-white/50">
                      <Paperclip className="h-3.5 w-3.5 text-accent" />
                      ATTACHED TO YOUR EMAIL
                    </p>
                    <div className="mt-2.5 flex flex-wrap items-center gap-x-3 gap-y-1 text-sm">
                      <span className="text-white/80">
                        {formatMinutes(estimate.minutes)} edit
                      </span>
                      <span className="text-white/30">·</span>
                      <span className="text-white/80">
                        {addOnNames.length ? addOnNames.join(" + ") : "No add-ons"}
                      </span>
                      <span className="text-white/30">·</span>
                      <span className="font-display font-bold text-accent">
                        {formatMoney(estimate.total)}
                      </span>
                    </div>
                    <p className="mt-2 text-xs text-white/35">
                      Comes from the calculator — adjust it anytime, this stays
                      in sync.{" "}
                      <a href="#calculator" className="text-accent/90 underline underline-offset-2 hover:text-accent">
                        Edit it
                      </a>
                    </p>
                  </div>
                )}

                <div className="mt-5 grid gap-4 sm:grid-cols-2">
                  <div>
                    <label htmlFor="cf-name" className="mb-1.5 block text-xs font-semibold text-white/60">
                      Name
                    </label>
                    <input
                      id="cf-name"
                      type="text"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="What do I call you?"
                      disabled={onCooldown}
                      className={inputCls}
                    />
                    {errors.name && (
                      <p className="mt-1.5 text-xs text-accent">{errors.name}</p>
                    )}
                  </div>
                  <div>
                    <label htmlFor="cf-email" className="mb-1.5 block text-xs font-semibold text-white/60">
                      Email
                    </label>
                    <input
                      id="cf-email"
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="you@email.com"
                      disabled={onCooldown}
                      className={inputCls}
                    />
                    {errors.email && (
                      <p className="mt-1.5 text-xs text-accent">{errors.email}</p>
                    )}
                  </div>
                </div>

                <div className="mt-4">
                  <label htmlFor="cf-cashapp" className="mb-1.5 block text-xs font-semibold text-white/60">
                    CashApp tag <span className="font-normal text-white/35">(optional — invoices go here)</span>
                  </label>
                  <input
                    id="cf-cashapp"
                    type="text"
                    value={cashappTag}
                    onChange={(e) => setCashappTag(e.target.value)}
                    placeholder="$yourtag"
                    disabled={onCooldown}
                    className={inputCls}
                  />
                </div>

                <div className="mt-4">
                  <label htmlFor="cf-notes" className="mb-1.5 block text-xs font-semibold text-white/60">
                    {mode === "edit" ? "Notes" : "Message"}
                  </label>
                  <textarea
                    id="cf-notes"
                    rows={5}
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder={
                      mode === "edit"
                        ? "Style refs, footage link (Drive/WeTransfer), deadline, anything I should know…"
                        : "What's on your mind?"
                    }
                    disabled={onCooldown}
                    className={cn(inputCls, "resize-none")}
                  />
                  {errors.notes && (
                    <p className="mt-1.5 text-xs text-accent">{errors.notes}</p>
                  )}
                </div>

                <button
                  type="submit"
                  disabled={status === "sending" || onCooldown}
                  className="mt-6 flex w-full items-center justify-center gap-2 rounded-xl bg-accent px-6 py-4 text-sm font-semibold text-white transition-transform hover:scale-[1.01] active:scale-[0.99] disabled:cursor-not-allowed disabled:opacity-60"
                >
                  {status === "sending" ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin" /> Sending…
                    </>
                  ) : (
                    <>
                      <Send className="h-4 w-4" />
                      {mode === "edit" ? "Send estimate + notes" : "Send message"}
                    </>
                  )}
                </button>

                {status === "error" && (
                  <p className="mt-4 flex items-center gap-2 rounded-xl border border-accent/30 bg-accent/10 px-4 py-3 text-sm text-white/80">
                    <AlertTriangle className="h-4 w-4 shrink-0 text-accent" />
                    That didn't send — check your connection and try again.
                  </p>
                )}

                {status === "unconfigured" && (
                  <div className="mt-4 rounded-xl border border-amber-400/30 bg-amber-400/10 px-4 py-3.5 text-sm text-amber-100/90">
                    <p className="flex items-center gap-2 font-semibold">
                      <AlertTriangle className="h-4 w-4 shrink-0" />
                      Almost there — EmailJS isn't wired up yet.
                    </p>
                    <p className="mt-1.5 leading-relaxed text-amber-100/70">
                      Paste your Service ID, Template ID and Public Key into{" "}
                      <code className="rounded bg-black/30 px-1.5 py-0.5 text-xs">
                        src/config.ts
                      </code>
                      , and make sure your template uses the variables listed
                      there. The full payload was logged to your browser console.
                    </p>
                  </div>
                )}
              </form>
            )}
          </div>
        </Reveal>

        <p className="mt-6 text-center text-xs text-white/35">
          Payments via CashApp only — {BRAND.cashappTag}
        </p>
      </div>
    </section>
  );
}
