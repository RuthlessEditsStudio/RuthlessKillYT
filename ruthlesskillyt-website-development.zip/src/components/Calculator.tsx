import { useEffect, useState } from "react";
import { Check, Minus, Plus, Send } from "lucide-react";
import {
  ADD_ONS,
  BRAND,
  FLAT_RATE,
  HALF_MIN_RATE,
  MAX_MINUTES,
  MIN_MINUTES,
  computeTotal,
  formatMinutes,
  formatMoney,
  maxVideosFor,
  type AddOnId,
  type EstimateState,
} from "../config";
import { cn } from "../utils/cn";
import Reveal from "./Reveal";
import TermsModal from "./TermsModal";

const QUICK_LENGTHS = [0.5, 1, 2, 3, 5, 10];
// The 20-video chip only renders where the cap allows it (30s and 1 min).
const QUICK_COUNTS = [1, 3, 5, 10, 20];

type Props = {
  estimate: EstimateState;
  onChange: (next: EstimateState) => void;
  termsAccepted: boolean;
  onAcceptTerms: () => void;
};

export default function Calculator({
  estimate,
  onChange,
  termsAccepted,
  onAcceptTerms,
}: Props) {
  const [minutes, setMinutes] = useState(estimate.minutes);
  const [count, setCount] = useState(estimate.count);
  const [addOns, setAddOns] = useState<AddOnId[]>(estimate.addOns);
  const [termsOpen, setTermsOpen] = useState(false);

  const maxCount = maxVideosFor(minutes);

  // Single source of truth: every change recomputes and pushes the estimate
  // up to App, so the contact form and the email can never go stale.
  useEffect(() => {
    onChange({
      minutes,
      count,
      addOns,
      total: computeTotal(minutes, count, addOns),
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [minutes, count, addOns]);

  // Changing length re-clamps the pack size so the count bar stays honest.
  const updateLength = (m: number) => {
    const next = Math.min(MAX_MINUTES, Math.max(MIN_MINUTES, m));
    setMinutes(next);
    setCount((c) => Math.min(c, maxVideosFor(next)));
  };

  const updateCount = (c: number) =>
    setCount(Math.min(maxCount, Math.max(1, Math.round(c))));

  const toggleAddOn = (id: AddOnId) =>
    setAddOns((cur) =>
      cur.includes(id) ? cur.filter((a) => a !== id) : [...cur, id]
    );

  const editCost = minutes * count * FLAT_RATE;

  // Gate: the form only exists once the terms have been agreed to.
  // If they've already agreed, jump straight to it.
  const handleContinue = () => {
    if (termsAccepted) {
      document.getElementById("contact")?.scrollIntoView({ behavior: "smooth" });
    } else {
      setTermsOpen(true);
    }
  };

  return (
    <section
      id="calculator"
      className="scroll-mt-20 border-t border-white/5 py-20 md:py-28"
    >
      <div className="mx-auto max-w-6xl px-5">
        <Reveal>
          <div className="text-center">
            <p className="mb-3 inline-flex items-center gap-2 text-xs font-semibold tracking-[0.2em] text-accent">
              <span className="h-px w-8 bg-accent" /> PRICING
            </p>
            <h2 className="font-display text-3xl font-bold tracking-tight md:text-5xl">
              Flat-rate calculator
            </h2>
            <p className="mt-4 max-w-lg mx-auto text-white/55">
              {formatMoney(FLAT_RATE)} per finished minute —{" "}
              {formatMoney(HALF_MIN_RATE)} for a 30-second video. Add-ons price
              per video and scale with length. No hourly billing, no surprises,
              CashApp only.
            </p>
          </div>
        </Reveal>

        <Reveal delay={120}>
          <div className="mx-auto mt-10 max-w-3xl rounded-3xl border border-white/10 bg-panel p-6 md:p-10">
            {/* Bar 1: length  ·  Bar 2: video count */}
            <div className="grid gap-10 md:grid-cols-2 md:gap-8">
              {/* Length */}
              <div>
                <div className="flex items-end justify-between">
                  <label
                    htmlFor="video-length"
                    className="text-sm font-semibold text-white/80"
                  >
                    Length per video
                  </label>
                  <span className="font-display text-3xl font-bold tracking-tight text-accent">
                    {formatMinutes(minutes)}
                  </span>
                </div>
                <input
                  id="video-length"
                  type="range"
                  min={MIN_MINUTES}
                  max={MAX_MINUTES}
                  step={0.5}
                  value={minutes}
                  onChange={(e) => updateLength(Number(e.target.value))}
                  className="mt-4 w-full cursor-pointer"
                />
                <div className="mt-2 flex items-center justify-between text-[11px] text-white/35">
                  <span>30 sec</span>
                  <span>{MAX_MINUTES} min</span>
                </div>
                <div className="mt-4 flex flex-wrap gap-2">
                  {QUICK_LENGTHS.map((m) => (
                    <button
                      key={m}
                      type="button"
                      onClick={() => updateLength(m)}
                      className={cn(
                        "rounded-full border px-3.5 py-1.5 text-xs font-medium transition-colors",
                        minutes === m
                          ? "border-accent bg-accent/10 text-accent"
                          : "border-white/10 text-white/55 hover:border-white/25 hover:text-white"
                      )}
                    >
                      {formatMinutes(m)}
                    </button>
                  ))}
                </div>
              </div>

              {/* Video count */}
              <div>
                <div className="flex items-end justify-between">
                  <span className="text-sm font-semibold text-white/80">
                    How many videos
                  </span>
                  <span className="flex items-center gap-3">
                    <button
                      type="button"
                      aria-label="Fewer videos"
                      onClick={() => updateCount(count - 1)}
                      disabled={count <= 1}
                      className="flex h-8 w-8 items-center justify-center rounded-full border border-white/10 text-white/60 transition-colors hover:border-white/25 hover:text-white disabled:cursor-not-allowed disabled:opacity-30"
                    >
                      <Minus className="h-4 w-4" />
                    </button>
                    <span className="w-12 text-center font-display text-3xl font-bold tracking-tight text-accent">
                      {count}
                    </span>
                    <button
                      type="button"
                      aria-label="More videos"
                      onClick={() => updateCount(count + 1)}
                      disabled={count >= maxCount}
                      className="flex h-8 w-8 items-center justify-center rounded-full border border-white/10 text-white/60 transition-colors hover:border-white/25 hover:text-white disabled:cursor-not-allowed disabled:opacity-30"
                    >
                      <Plus className="h-4 w-4" />
                    </button>
                  </span>
                </div>
                <div className="mt-4 h-1.5 w-full overflow-hidden rounded-full bg-white/10">
                  <div
                    className="h-full rounded-full bg-accent transition-[width] duration-300"
                    style={{ width: `${(count / maxCount) * 100}%` }}
                  />
                </div>
                <p className="mt-2 text-[11px] text-white/35">
                  Up to {maxCount} {maxCount === 1 ? "video" : "videos"} at{" "}
                  {formatMinutes(minutes)} each
                </p>
                <div className="mt-4 flex flex-wrap gap-2">
                  {QUICK_COUNTS.filter((c) => c <= maxCount).map((c) => (
                    <button
                      key={c}
                      type="button"
                      onClick={() => updateCount(c)}
                      className={cn(
                        "rounded-full border px-3.5 py-1.5 text-xs font-medium transition-colors",
                        count === c
                          ? "border-accent bg-accent/10 text-accent"
                          : "border-white/10 text-white/55 hover:border-white/25 hover:text-white"
                      )}
                    >
                      {c} {c === 1 ? "video" : "videos"}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Add-ons — per-video price, live-scaled by length */}
            <div className="mt-9">
              <p className="text-sm font-semibold text-white/80">
                Add-ons{" "}
                <span className="font-normal text-white/40">
                  (per video — price scales with length)
                </span>
              </p>
              <p className="mt-1 text-xs text-white/40">
                Standard turnaround is 3–7 days. Rush drops that to 24–72 hours.
              </p>
              <div className="mt-4 grid gap-3">
                {ADD_ONS.map((a) => {
                  const on = addOns.includes(a.id);
                  const perVideo = a.priceFor(minutes);
                  return (
                    <button
                      key={a.id}
                      type="button"
                      onClick={() => toggleAddOn(a.id)}
                      aria-pressed={on}
                      className={cn(
                        "rounded-2xl border p-4 text-left transition-colors",
                        on
                          ? "border-accent/60 bg-accent/10"
                          : "border-white/10 bg-panel-2 hover:border-white/25"
                      )}
                    >
                      <span className="flex items-center justify-between">
                        <span className="text-sm font-semibold text-white">
                          {a.name}
                        </span>
                        <span
                          className={cn(
                            "flex h-4.5 w-4.5 items-center justify-center rounded-full border",
                            on ? "border-accent bg-accent" : "border-white/25"
                          )}
                        >
                          {on && <Check className="h-3 w-3 text-white" />}
                        </span>
                      </span>
                      <span className="mt-1.5 block text-xs leading-relaxed text-white/45">
                        {a.desc}
                      </span>
                      <span className="mt-2.5 block font-display text-sm font-bold text-white/80">
                        +{formatMoney(perVideo)}
                        <span className="text-white/40"> /video</span>
                        {count > 1 && (
                          <span className="ml-1.5 text-xs font-semibold text-accent">
                            ×{count} = {formatMoney(perVideo * count)}
                          </span>
                        )}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>



            {/* Breakdown */}
            <div className="mt-9 border-t border-white/10 pt-6">
              <dl className="space-y-2.5 text-sm">
                <div className="flex justify-between text-white/60">
                  <span>
                    Edit — {formatMinutes(minutes)} × {count}{" "}
                    {count === 1 ? "video" : "videos"} × {formatMoney(FLAT_RATE)}
                    /min
                  </span>
                  <span className="text-white/85">{formatMoney(editCost)}</span>
                </div>
                {ADD_ONS.filter((a) => addOns.includes(a.id)).map((a) => (
                  <div
                    key={a.id}
                    className="flex justify-between text-white/60"
                  >
                    <span>
                      {a.name} — {count} × {formatMoney(a.priceFor(minutes))}
                    </span>
                    <span className="text-white/85">
                      +{formatMoney(a.priceFor(minutes) * count)}
                    </span>
                  </div>
                ))}
              </dl>
              <div className="mt-5 flex flex-wrap items-center justify-between gap-3 border-t border-white/10 pt-5">
                <div>
                  <p className="font-display text-4xl font-bold tracking-tight">
                    {formatMoney(estimate.total)}
                  </p>
                  <p className="mt-1 text-xs text-white/40">
                    Payment via {BRAND.cashappTag} after the video type or scope has been agreed upon.
                    {count > 1 && (
                      <span className="text-white/30">
                        {" "}
                        · {count} videos, {formatMoney(
                          estimate.total / count
                        )}{" "}
                        each
                      </span>
                    )}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={handleContinue}
                  className="inline-flex items-center gap-2 rounded-xl bg-accent px-6 py-3.5 text-sm font-semibold text-white transition-transform hover:scale-[1.02] active:scale-[0.98]"
                >
                  Send this estimate <Send className="h-4 w-4" />
                </button>
              </div>
              <p className="mt-4 text-center text-[11px] text-white/30">
                Estimate only — final price is confirmed before payment.
              </p>
            </div>
          </div>
        </Reveal>
      </div>

      <TermsModal
        open={termsOpen}
        onClose={() => setTermsOpen(false)}
        onAccept={() => {
          setTermsOpen(false);
          onAcceptTerms();
        }}
      />
    </section>
  );
}
