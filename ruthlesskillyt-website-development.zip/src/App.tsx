import { useState } from "react";
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import Showcase from "./components/Showcase";
import Calculator from "./components/Calculator";
import FAQ from "./components/FAQ";
import ContactForm from "./components/ContactForm";
import Footer from "./components/Footer";
import ChatWidget from "./components/ChatWidget";
import { computeTotal, type EstimateState } from "./config";

/**
 * The estimate lives here — one source of truth. The calculator writes it,
 * the contact form (and the EmailJS payload) reads it. No stale copies.
 */
export default function App() {
  // Page opens at 30 sec × 1 video — the simplest possible estimate.
  const [estimate, setEstimate] = useState<EstimateState>({
    minutes: 0.5,
    count: 1,
    addOns: [],
    total: computeTotal(0.5, 1, []),
  });

  // The contact form doesn't exist until the terms are agreed to.
  // This is deliberately NOT persisted (no localStorage/sessionStorage), so
  // every fresh visit, reload, or return after the 24h lockout requires
  // hitting "I agree" again before the form is reachable.
  const [termsAccepted, setTermsAccepted] = useState(false);

  const handleAcceptTerms = () => {
    setTermsAccepted(true);
    // Let the section mount, then bring them to it.
    requestAnimationFrame(() => {
      setTimeout(() => {
        document
          .getElementById("contact")
          ?.scrollIntoView({ behavior: "smooth", block: "start" });
      }, 80);
    });
  };

  return (
    <div className="min-h-screen bg-ink font-body text-white">
      <Navbar termsAccepted={termsAccepted} />
      <main>
        <Hero />
        <Showcase />
        <Calculator
          estimate={estimate}
          onChange={setEstimate}
          termsAccepted={termsAccepted}
          onAcceptTerms={handleAcceptTerms}
        />
        <FAQ />
        <ContactForm
          estimate={estimate}
          termsAccepted={termsAccepted}
          onRequireTerms={() => setTermsAccepted(false)}
        />
      </main>
      <Footer />
      <ChatWidget />
    </div>
  );
}
