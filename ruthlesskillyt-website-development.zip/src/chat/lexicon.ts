// ============================================================
//  LEXICON — the bot's "vocabulary"
//
//  Instead of only matching literal keywords, every known word maps to
//  a CONCEPT plus a sentiment/intensity. That means the bot understands
//  "pricey", "steep", "costly" and "rip off" all point at the same idea
//  with different heat behind them — so it can answer the *meaning*
//  rather than the exact string.
// ============================================================

export type Concept =
  | "cost" | "cheap_want" | "expensive_feel"
  | "time" | "urgent" | "slow"
  | "quality" | "trust_doubt" | "praise"
  | "quantity" | "limit"
  | "video" | "platform" | "style"
  | "process" | "payment" | "ownership" | "revision"
  | "commit" | "decline" | "confused" | "frustrated"
  | "social" | "person" | "profanity";

export type WordSense = {
  concept: Concept;
  /** -1 negative, 0 neutral, +1 positive */
  tone: -1 | 0 | 1;
  /** how strongly this word signals its concept */
  weight: number;
};

export const LEXICON: Record<string, WordSense> = {
  // ---- cost ----
  price: { concept: "cost", tone: 0, weight: 2 },
  cost: { concept: "cost", tone: 0, weight: 2 },
  rate: { concept: "cost", tone: 0, weight: 2 },
  charge: { concept: "cost", tone: 0, weight: 2 },
  quote: { concept: "cost", tone: 0, weight: 2 },
  fee: { concept: "cost", tone: 0, weight: 1.5 },
  total: { concept: "cost", tone: 0, weight: 1 },
  dollar: { concept: "cost", tone: 0, weight: 1 },
  money: { concept: "cost", tone: 0, weight: 1 },
  budget: { concept: "cost", tone: 0, weight: 1.5 },
  pay: { concept: "payment", tone: 0, weight: 1.5 },

  expensive: { concept: "expensive_feel", tone: -1, weight: 3 },
  pricey: { concept: "expensive_feel", tone: -1, weight: 3 },
  steep: { concept: "expensive_feel", tone: -1, weight: 2.5 },
  costly: { concept: "expensive_feel", tone: -1, weight: 2.5 },
  overpriced: { concept: "expensive_feel", tone: -1, weight: 3 },
  ripoff: { concept: "expensive_feel", tone: -1, weight: 3 },
  outrageous: { concept: "expensive_feel", tone: -1, weight: 3 },
  broke: { concept: "expensive_feel", tone: -1, weight: 2 },
  afford: { concept: "expensive_feel", tone: -1, weight: 2 },

  cheaper: { concept: "cheap_want", tone: -1, weight: 2.5 },
  discount: { concept: "cheap_want", tone: -1, weight: 2.5 },
  deal: { concept: "cheap_want", tone: 0, weight: 1.5 },
  lower: { concept: "cheap_want", tone: -1, weight: 2 },
  haggle: { concept: "cheap_want", tone: -1, weight: 2 },
  negotiate: { concept: "cheap_want", tone: -1, weight: 2 },
  free: { concept: "cheap_want", tone: -1, weight: 1.5 },

  // ---- time ----
  fast: { concept: "time", tone: 0, weight: 2 },
  quick: { concept: "time", tone: 0, weight: 2 },
  turnaround: { concept: "time", tone: 0, weight: 3 },
  delivery: { concept: "time", tone: 0, weight: 2 },
  deliver: { concept: "time", tone: 0, weight: 2 },
  eta: { concept: "time", tone: 0, weight: 2 },

  urgent: { concept: "urgent", tone: -1, weight: 3 },
  asap: { concept: "urgent", tone: -1, weight: 3 },
  deadline: { concept: "urgent", tone: -1, weight: 3 },
  rush: { concept: "urgent", tone: 0, weight: 3 },
  tonight: { concept: "urgent", tone: -1, weight: 2.5 },
  tomorrow: { concept: "urgent", tone: -1, weight: 2.5 },
  hurry: { concept: "urgent", tone: -1, weight: 2.5 },

  slow: { concept: "slow", tone: -1, weight: 2 },
  forever: { concept: "slow", tone: -1, weight: 1.5 },

  // ---- trust / quality ----
  scam: { concept: "trust_doubt", tone: -1, weight: 3 },
  legit: { concept: "trust_doubt", tone: 0, weight: 2.5 },
  trust: { concept: "trust_doubt", tone: 0, weight: 2.5 },
  guarantee: { concept: "trust_doubt", tone: 0, weight: 2 },
  refund: { concept: "trust_doubt", tone: -1, weight: 2.5 },
  sketchy: { concept: "trust_doubt", tone: -1, weight: 3 },
  proof: { concept: "trust_doubt", tone: 0, weight: 2 },
  reviews: { concept: "trust_doubt", tone: 0, weight: 2 },

  good: { concept: "quality", tone: 1, weight: 1 },
  quality: { concept: "quality", tone: 0, weight: 2 },
  clean: { concept: "quality", tone: 1, weight: 1 },
  fire: { concept: "praise", tone: 1, weight: 2 },
  dope: { concept: "praise", tone: 1, weight: 2 },
  sick: { concept: "praise", tone: 1, weight: 1.5 },
  amazing: { concept: "praise", tone: 1, weight: 2 },
  awesome: { concept: "praise", tone: 1, weight: 1.5 },
  nice: { concept: "praise", tone: 1, weight: 1 },
  love: { concept: "praise", tone: 1, weight: 1.5 },

  // ---- quantity / limits ----
  bulk: { concept: "quantity", tone: 0, weight: 3 },
  batch: { concept: "quantity", tone: 0, weight: 3 },
  multiple: { concept: "quantity", tone: 0, weight: 2 },
  bunch: { concept: "quantity", tone: 0, weight: 2 },
  several: { concept: "quantity", tone: 0, weight: 2 },
  recurring: { concept: "quantity", tone: 0, weight: 2.5 },
  monthly: { concept: "quantity", tone: 0, weight: 2 },
  weekly: { concept: "quantity", tone: 0, weight: 2 },

  limit: { concept: "limit", tone: -1, weight: 3 },
  limits: { concept: "limit", tone: -1, weight: 3 },
  limited: { concept: "limit", tone: -1, weight: 2.5 },
  cap: { concept: "limit", tone: -1, weight: 2.5 },
  maximum: { concept: "limit", tone: 0, weight: 2.5 },
  max: { concept: "limit", tone: 0, weight: 2 },
  restriction: { concept: "limit", tone: -1, weight: 2.5 },

  // ---- video / platform / style ----
  video: { concept: "video", tone: 0, weight: 1 },
  clip: { concept: "video", tone: 0, weight: 1.5 },
  footage: { concept: "video", tone: 0, weight: 2 },
  raw: { concept: "video", tone: 0, weight: 1.5 },

  tiktok: { concept: "platform", tone: 0, weight: 2.5 },
  reel: { concept: "platform", tone: 0, weight: 2.5 },
  short: { concept: "platform", tone: 0, weight: 2 },
  youtube: { concept: "platform", tone: 0, weight: 2.5 },
  instagram: { concept: "platform", tone: 0, weight: 2.5 },
  twitch: { concept: "platform", tone: 0, weight: 2 },

  gaming: { concept: "style", tone: 0, weight: 2.5 },
  vlog: { concept: "style", tone: 0, weight: 2.5 },
  podcast: { concept: "style", tone: 0, weight: 2.5 },
  montage: { concept: "style", tone: 0, weight: 2.5 },
  caption: { concept: "style", tone: 0, weight: 2 },
  subtitle: { concept: "style", tone: 0, weight: 2 },
  transition: { concept: "style", tone: 0, weight: 2 },
  effect: { concept: "style", tone: 0, weight: 1.5 },
  music: { concept: "style", tone: 0, weight: 1.5 },
  hook: { concept: "style", tone: 0, weight: 2 },
  color: { concept: "style", tone: 0, weight: 1.5 },

  // ---- process ----
  process: { concept: "process", tone: 0, weight: 2 },
  form: { concept: "process", tone: 0, weight: 2 },
  include: { concept: "process", tone: 0, weight: 1.5 },
  upload: { concept: "process", tone: 0, weight: 2 },
  drive: { concept: "process", tone: 0, weight: 2 },
  wetransfer: { concept: "process", tone: 0, weight: 2.5 },
  dropbox: { concept: "process", tone: 0, weight: 2 },

  cashapp: { concept: "payment", tone: 0, weight: 3 },
  paypal: { concept: "payment", tone: 0, weight: 2.5 },
  venmo: { concept: "payment", tone: 0, weight: 2.5 },
  zelle: { concept: "payment", tone: 0, weight: 2.5 },
  crypto: { concept: "payment", tone: 0, weight: 2.5 },
  card: { concept: "payment", tone: 0, weight: 1.5 },
  invoice: { concept: "payment", tone: 0, weight: 2 },

  revision: { concept: "revision", tone: 0, weight: 3 },
  revisions: { concept: "revision", tone: 0, weight: 3 },
  redo: { concept: "revision", tone: -1, weight: 2 },
  tweak: { concept: "revision", tone: 0, weight: 2 },
  fix: { concept: "revision", tone: 0, weight: 1.5 },

  copyright: { concept: "ownership", tone: 0, weight: 2.5 },
  monetize: { concept: "ownership", tone: 0, weight: 2.5 },
  license: { concept: "ownership", tone: 0, weight: 2.5 },
  ownership: { concept: "ownership", tone: 0, weight: 2.5 },

  // ---- conversational state ----
  ready: { concept: "commit", tone: 1, weight: 2.5 },
  order: { concept: "commit", tone: 1, weight: 2 },
  book: { concept: "commit", tone: 1, weight: 2 },
  buy: { concept: "commit", tone: 1, weight: 2.5 },
  hire: { concept: "commit", tone: 1, weight: 2.5 },

  nevermind: { concept: "decline", tone: -1, weight: 3 },
  later: { concept: "decline", tone: -1, weight: 1.5 },
  maybe: { concept: "decline", tone: 0, weight: 1 },
  thinking: { concept: "decline", tone: 0, weight: 1 },

  confused: { concept: "confused", tone: -1, weight: 2.5 },
  understand: { concept: "confused", tone: 0, weight: 1.5 },
  huh: { concept: "confused", tone: -1, weight: 2 },
  what: { concept: "confused", tone: 0, weight: 0.5 },

  useless: { concept: "frustrated", tone: -1, weight: 3 },
  broken: { concept: "frustrated", tone: -1, weight: 3 },
  stupid: { concept: "frustrated", tone: -1, weight: 2.5 },
  dumb: { concept: "frustrated", tone: -1, weight: 2.5 },
  annoying: { concept: "frustrated", tone: -1, weight: 2.5 },
  wrong: { concept: "frustrated", tone: -1, weight: 2 },
  repeating: { concept: "frustrated", tone: -1, weight: 3 },
  answering: { concept: "frustrated", tone: -1, weight: 2 },

  bot: { concept: "person", tone: 0, weight: 2.5 },
  robot: { concept: "person", tone: 0, weight: 2.5 },
  human: { concept: "person", tone: 0, weight: 2.5 },
  real: { concept: "person", tone: 0, weight: 1 },

  discord: { concept: "social", tone: 0, weight: 2.5 },
  dm: { concept: "social", tone: 0, weight: 2 },
  email: { concept: "social", tone: 0, weight: 1.5 },
  insta: { concept: "social", tone: 0, weight: 2 },

  fuck: { concept: "profanity", tone: -1, weight: 2 },
  shit: { concept: "profanity", tone: -1, weight: 1.5 },
  damn: { concept: "profanity", tone: -1, weight: 1 },
  hell: { concept: "profanity", tone: -1, weight: 1 },
};

/** Words that signal the message has drifted off the product entirely. */
export const OFF_TOPIC_SIGNALS: Record<string, string> = {
  weather: "smalltalk",
  joke: "joke",
  funny: "joke",
  lol: "joke",
  lmao: "joke",
  haha: "joke",
  meme: "joke",
  bored: "smalltalk",
  hungry: "smalltalk",
  tired: "smalltalk",
  school: "smalltalk",
  homework: "smalltalk",
  girlfriend: "personal",
  boyfriend: "personal",
  age: "personal",
  old: "personal",
  where: "personal",
  live: "personal",
  name: "personal",
  fortnite: "gametalk",
  minecraft: "gametalk",
  valorant: "gametalk",
  cod: "gametalk",
  roblox: "gametalk",
  crypto2: "unrelated",
  homework2: "unrelated",
  recipe: "unrelated",
  weatherman: "unrelated",
  fiverr: "competitor",
  upwork: "competitor",
  competitor: "competitor",
  someone: "competitor",
  else: "competitor",
};
