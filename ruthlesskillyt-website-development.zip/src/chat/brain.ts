// ============================================================
//  CHAT BRAIN v4
//
//  Principles:
//   - ANSWER the question first, with real numbers. Never deflect
//     to "go use the calculator" as the substance of a reply.
//   - NEVER auto-scroll the page. Navigation is offered as a chip
//     the person can tap when they're done reading.
//   - Warm, plain, human. Contractions, short sentences, no pitch voice.
//   - Every intent has escalating variants so it never repeats itself.
// ============================================================

import { FLAT_RATE, computeTotal, formatMoney, maxVideosFor } from "../config";
import { LEXICON, OFF_TOPIC_SIGNALS, type Concept } from "./lexicon";

// ---------- Normalization ----------

const SLANG: Record<string, string> = {
  u: "you", ur: "your", pls: "please", plz: "please", thx: "thanks",
  ty: "thanks", sup: "hey", hiya: "hey", hii: "hi", helo: "hello",
  vid: "video", vids: "videos", vidz: "videos", edits: "edit",
  editing: "edit", pricing: "price", prices: "price", costs: "cost",
  charges: "charge", tik: "tiktok", tt: "tiktok", yt: "youtube",
  ig: "instagram", reels: "reel", shorts: "short", clips: "clip",
  cheap: "cheaper", "rip off": "ripoff", "cash app": "cashapp",
  "too much": "expensive", "way much": "expensive",
};

export function normalize(input: string): string {
  let s = input.toLowerCase().trim();
  s = s.replace(/[^\w\s$]/g, " ").replace(/\s+/g, " ");
  for (const [from, to] of Object.entries(SLANG)) {
    s = s.replace(new RegExp(`\\b${from}\\b`, "g"), to);
  }
  return s.trim();
}

const tokens = (s: string) => s.split(" ").filter(Boolean);

function editDistance(a: string, b: string): number {
  if (Math.abs(a.length - b.length) > 2) return 99;
  const dp = Array.from({ length: b.length + 1 }, (_, i) => i);
  for (let i = 1; i <= a.length; i++) {
    let prev = dp[0];
    dp[0] = i;
    for (let j = 1; j <= b.length; j++) {
      const tmp = dp[j];
      dp[j] = Math.min(dp[j] + 1, dp[j - 1] + 1, prev + (a[i - 1] === b[j - 1] ? 0 : 1));
      prev = tmp;
    }
  }
  return dp[b.length];
}

function lookup(tok: string) {
  if (LEXICON[tok]) return { key: tok, sense: LEXICON[tok] };
  if (tok.length >= 6) {
    for (const key of Object.keys(LEXICON)) {
      if (key.length >= 5 && editDistance(tok, key) <= 1) {
        return { key, sense: LEXICON[key] };
      }
    }
  }
  return null;
}

export type Understanding = {
  concepts: Map<Concept, number>;
  tone: number;
  offTopic: string | null;
  known: number;
  total: number;
};

export function understand(norm: string): Understanding {
  const toks = tokens(norm);
  const concepts = new Map<Concept, number>();
  let tone = 0;
  let known = 0;
  let offTopic: string | null = null;

  for (const t of toks) {
    if (!offTopic && OFF_TOPIC_SIGNALS[t]) offTopic = OFF_TOPIC_SIGNALS[t];
    const hit = lookup(t);
    if (!hit) continue;
    known++;
    concepts.set(hit.sense.concept, (concepts.get(hit.sense.concept) ?? 0) + hit.sense.weight);
    tone += hit.sense.tone;
  }
  return { concepts, tone, offTopic, known, total: toks.length };
}

// ---------- Entities ----------

export type Entities = { minutes?: number; count?: number };

const NUM: Record<string, number> = {
  one: 1, two: 2, three: 3, four: 4, five: 5, six: 6, seven: 7, eight: 8,
  nine: 9, ten: 10, twelve: 12, fifteen: 15, twenty: 20, thirty: 30,
  forty: 40, fifty: 50, hundred: 100, couple: 2, few: 3, dozen: 12,
};

export function extractEntities(raw: string): Entities {
  const s = normalize(raw);
  const out: Entities = {};
  const deadline = /\b(week|weeks|day|days|hour|hours|today|tonight|tomorrow)\b/.test(s);

  const sec = s.match(/(\d+(?:\.\d+)?)\s*(?:sec|secs|second|seconds)\b/);
  if (sec) out.minutes = Math.round((parseFloat(sec[1]) / 60) * 2) / 2;

  if (out.minutes === undefined && !deadline) {
    const min = s.match(/(\d+(?:\.\d+)?)\s*(?:min|mins|minute|minutes)\b/);
    if (min) out.minutes = Math.round(parseFloat(min[1]) * 2) / 2;
  }
  if (/\bhalf a minute\b|\bhalf minute\b/.test(s)) out.minutes = 0.5;
  if (/\bminute and a half\b/.test(s)) out.minutes = 1.5;
  if (out.minutes !== undefined) out.minutes = Math.min(10, Math.max(0.5, out.minutes));

  // "30 videos that are 30 seconds" / "30 30 second videos"
  const combo = s.match(
    /(\d+|twenty|thirty|forty|fifty|hundred|dozen)\s+(?:\w+\s+){0,3}?(\d+)\s*(?:sec|second|seconds|min|minute|minutes)/
  );
  if (combo) {
    const n = /^\d+$/.test(combo[1]) ? parseInt(combo[1], 10) : NUM[combo[1]];
    if (n && n >= 1) out.count = Math.min(999, n);
  }

  if (out.count === undefined) {
    const cnt = s.match(
      /(\d+|one|two|three|four|five|six|seven|eight|nine|ten|twelve|fifteen|twenty|thirty|forty|fifty|hundred|couple|few|dozen)\s+(?:\d+\s*(?:sec|second|seconds|min|minute|minutes)\s+)?(?:short\s+|long\s+|quick\s+)?(?:video|clip)/
    );
    if (cnt) {
      const n = /^\d+$/.test(cnt[1]) ? parseInt(cnt[1], 10) : NUM[cnt[1]];
      if (n && n >= 1) out.count = Math.min(999, n);
    }
  }
  return out;
}

// ---------- Memory ----------

export type ChatMemory = {
  minutes?: number;
  count?: number;
  lastIntent?: string;
  hits: Record<string, number>;
  misses: number;
  turns: number;
  seen: string[];
};

export const emptyMemory = (): ChatMemory => ({ hits: {}, misses: 0, turns: 0, seen: [] });

/** `nav` renders as a tappable button — the page NEVER scrolls on its own. */
export type Reply = {
  text: string;
  chips?: string[];
  nav?: { label: string; target: string };
};

// ---------- Helpers ----------

function variant<T>(list: T[], n: number): T {
  return list[Math.min(n, list.length - 1)];
}

const BRIDGES = [
  "Anyway — what are you looking to get edited?",
  "But yeah, back to it: got footage you want cut?",
  "Speaking of which — what kind of videos are you making?",
  "Anyway, what brought you here? Editing something?",
];
const bridge = (n: number) => BRIDGES[n % BRIDGES.length];

const lengthLabel = (m: number) =>
  m < 1 ? `${Math.round(m * 60)}-second` : `${m}-minute`;

function priceLine(minutes: number, count: number): string {
  const total = computeTotal(minutes, count, []);
  const each = computeTotal(minutes, 1, []);
  return count > 1
    ? `${count} × ${lengthLabel(minutes)} videos comes to **${formatMoney(total)}** — ${formatMoney(each)} each.`
    : `A ${lengthLabel(minutes)} video is **${formatMoney(computeTotal(minutes, 1, []))}**.`;
}

const CALC = { label: "Open the calculator", target: "calculator" };
const WORK = { label: "See the work", target: "work" };

// ---------- Intents ----------

type Ctx = { mem: ChatMemory; ent: Entities; u: Understanding; n: number };
type Intent = {
  id: string;
  phrases?: string[];
  concepts?: Partial<Record<Concept, number>>;
  build: (c: Ctx) => Reply;
};

const INTENTS: Intent[] = [
  // ---------- limits: answer with real math, don't deflect ----------
  {
    id: "limits",
    phrases: [
      "more than 20", "why is there limit", "why are there limit", "whats the limit",
      "why the limit", "why limit", "why cant i", "why can i not", "why couldnt i",
      "max videos", "order more than", "over 20", "more than twenty", "limits on this",
      "30 videos", "50 videos", "100 videos",
    ],
    concepts: { limit: 2.5 },
    build: ({ ent, mem }) => {
      const minutes = ent.minutes ?? mem.minutes ?? 0.5;
      const cap = maxVideosFor(minutes);
      const want = ent.count ?? mem.count;

      if (want && want > cap) {
        const total = computeTotal(minutes, want, []);
        const each = computeTotal(minutes, 1, []);
        return {
          text: `Oh you totally can — the slider just stops at ${cap}, that's all. It's not a rule, it's me keeping the tool from letting someone accidentally book a month of work in one tap.\n\n${want} × ${lengthLabel(
            minutes
          )} videos would be **${formatMoney(total)}** at the normal rate (${formatMoney(
            each
          )} each — no bulk penalty, no bulk discount either, it's just flat).\n\nFor a batch that size I'd want to talk timeline with you though. ${want} videos is real work, so it'd land closer to a couple weeks than the usual 3–7 days unless we split it into drops.\n\nPut "${want} videos" in the notes when you reach out and we'll sort it properly.`,
          chips: ["How would the timeline work?", "What do you need from me?"],
          nav: CALC,
        };
      }

      return {
        text: `The cap's just a guardrail on the slider, not a real limit. At ${lengthLabel(
          minutes
        )} it goes up to ${cap} per order.\n\nIf you want more than that, it's genuinely fine — same flat rate, I'd just want to talk timeline with you first so I'm not promising something unrealistic. Mention the number in the notes and we'll figure it out.`,
        chips: ["What about 30 videos?", "How long would that take?"],
      };
    },
  },

  // ---------- timeline for big batches ----------
  {
    id: "batch_time",
    phrases: [
      "how would the timeline work", "how long would that take", "timeline for",
      "how long for a batch", "how fast for a batch", "split into drops",
    ],
    build: ({ mem }) => {
      const count = mem.count ?? 20;
      return {
        text: `Depends on the size. Rough guide:\n\n**1–5 videos** — the normal 3–7 days\n**6–15** — usually 1–2 weeks\n**${count > 15 ? count : "16"}+** — I'd rather split it into drops so you're posting while I'm still cutting the rest\n\nThe drop approach is honestly better for you anyway — you're not sitting on nothing for two weeks waiting on a giant batch.`,
        chips: ["What do you need from me?", "What's the price?"],
      };
    },
  },

  // ---------- meta / frustration ----------
  {
    id: "meta",
    phrases: [
      "keep saying the same", "same thing", "already said", "not answering",
      "answering my question", "not even answering", "didnt answer",
      "you re broken", "doesnt make sense", "wrong answer", "not helping",
      "you suck", "terrible bot", "stop redirecting", "quit sending me",
    ],
    concepts: { frustrated: 2.5 },
    build: ({ n }) => ({
      text: variant(
        [
          "Yeah, that's fair — I dodged it. Ask me again and I'll actually answer instead of pointing at a page.",
          "You're right and I'll stop doing that. Here's everything plainly:\n\n**Price** — $7.50 a finished minute, so $3.75 for 30 seconds\n**Speed** — 3–7 days normally, 24–72 hours with Rush\n**To start** — a footage link and a rough idea of the vibe\n\nWhat else do you want to know?",
          "I'm genuinely not getting you and I don't want to keep wasting your time.\n\nWrite it in the form's notes box — the actual editor reads those and replies within a day. He's better at this than I am.",
        ],
        n
      ),
      chips: ["Pricing", "Turnaround", "What to send", "Talk to a human"],
    }),
  },

  // ---------- price ----------
  {
    id: "price",
    phrases: ["how much", "what do you charge", "what does it cost", "price for", "whats the price"],
    concepts: { cost: 2 },
    build: ({ mem, ent, n }) => {
      const minutes = ent.minutes ?? mem.minutes;
      const count = ent.count ?? mem.count ?? 1;
      if (minutes) {
        return {
          text: `${priceLine(minutes, count)}\n\nThat's the flat rate — ${formatMoney(
            FLAT_RATE
          )} a finished minute, no hourly billing and nothing added on at the end.`,
          chips: ["How fast?", "What do you need from me?", "I'm ready"],
          nav: CALC,
        };
      }
      return {
        text: variant(
          [
            `Flat ${formatMoney(FLAT_RATE)} per finished minute. So 30 seconds is ${formatMoney(
              FLAT_RATE / 2
            )}, a full minute is ${formatMoney(FLAT_RATE)}, two minutes is ${formatMoney(
              FLAT_RATE * 2
            )}.\n\nHow long are yours usually? I'll give you the actual number.`,
            `Same rate — ${formatMoney(FLAT_RATE / 2)} for 30s, ${formatMoney(
              FLAT_RATE
            )} a minute.\n\nTell me a length and how many and I'll work it out for you.`,
          ],
          n
        ),
        chips: ["About 30 seconds", "1–2 minutes", "5 videos"],
      };
    },
  },

  // ---------- expensive ----------
  {
    id: "expensive",
    phrases: ["too expensive", "thats a lot", "any discount", "go lower", "still expensive", "cant afford", "out of my budget"],
    concepts: { expensive_feel: 2, cheap_want: 2 },
    build: ({ n }) => ({
      text: variant(
        [
          `A 30-second edit is ${formatMoney(
            FLAT_RATE / 2
          )} — less than lunch, and it sits on your profile permanently.\n\nThe rate's flat so there's nothing to haggle over, but batching is the smart move if you're watching the budget. Same price each, one turnaround for the set.`,
          `I hear you, and I'm not going to pretend it's nothing.\n\nIf money's tight, do one 30-second video at ${formatMoney(
            FLAT_RATE / 2
          )} and see if it actually moves your numbers. If it flops you're out four bucks. If it works, then scaling up is an easy call.`,
          `Then let's not force it — seriously.\n\nI'd rather you spend it when it makes sense than talk you into something you'll regret. Site's not going anywhere, and neither is the rate.`,
        ],
        n
      ),
      chips: n >= 1 ? ["Just one to start", "Show me the work"] : ["Price for 5 videos?", "Just one to start"],
    }),
  },

  // ---------- speed ----------
  {
    id: "speed",
    phrases: ["how fast", "how long does it take", "turnaround", "how soon", "when will i get"],
    concepts: { time: 2, slow: 2 },
    build: ({ n }) => ({
      text: variant(
        [
          "3–7 days from when payment clears and I've got your footage.\n\nIf you're on a deadline, Rush pulls it down to 24–72 hours for a few dollars more per video.",
          "Same as before — 3–7 days normally, 24–72 hours if you add Rush.",
        ],
        n
      ),
      chips: ["What's rush cost?", "What do you need from me?", "I'm ready"],
    }),
  },

  {
    id: "deadline",
    phrases: ["this week", "by friday", "by monday", "need it by", "by tomorrow", "need it fast"],
    concepts: { urgent: 2.5 },
    build: ({ mem, ent }) => {
      const minutes = ent.minutes ?? mem.minutes ?? 0.5;
      const rush = minutes < 1 ? 2 : Math.max(4, Math.ceil(1.5 * minutes));
      return {
        text: `That's doable. Rush turns it around in 24–72 hours — ${formatMoney(
          rush
        )} extra per video at that length.\n\nPut your real deadline in the notes when you reach out and it'll get confirmed before you pay anything.`,
        chips: ["What do you need from me?", "What's the total?"],
        nav: CALC,
      };
    },
  },

  {
    id: "rush",
    phrases: ["how much is rush", "rush cost", "rush fee", "whats rush"],
    concepts: { urgent: 1.5 },
    build: ({ mem, ent }) => {
      const minutes = ent.minutes ?? mem.minutes ?? 0.5;
      const rush = minutes < 1 ? 2 : Math.max(4, Math.ceil(1.5 * minutes));
      return {
        text: `${formatMoney(rush)} per video at ${lengthLabel(
          minutes
        )} length. Puts you at the front of the queue — 24–72 hours instead of 3–7 days.`,
        chips: ["What's the total then?", "I'm ready"],
      };
    },
  },

  // ---------- process ----------
  {
    id: "process",
    phrases: [
      "what do you need", "how does this work", "how do i start", "what do i send",
      "what should i include", "what do i put", "how do i order", "next step",
      "what happens after", "what happens next",
    ],
    concepts: { process: 2 },
    build: () => ({
      text: "Three things, that's it:\n\n**1.** A Drive or WeTransfer link with your raw clips\n**2.** The vibe you're after — a reference video, a style, or honestly just \"punchy gaming edit\"\n**3.** Any deadline\n\nWe agree on scope and price before money moves. Then I cut it and send it back.",
      chips: ["How much?", "What styles do you do?", "I'm ready"],
    }),
  },

  {
    id: "raw_quality",
    phrases: [
      "what if my footage", "bad footage", "phone camera", "low quality footage",
      "what format", "file format", "how do i send big", "too big to send",
      "how much footage", "how many clips should",
    ],
    build: () => ({
      text: "Phone footage is completely fine — most of what I get is shot on a phone.\n\nAny format works (MP4, MOV, whatever your camera spits out). Don't worry about trimming or organizing it first either. Send the messy folder, that's normal. Drive or WeTransfer handles the size.",
      chips: ["What do you need from me?", "How much?"],
    }),
  },

  // ---------- styles / capability ----------
  {
    id: "styles",
    phrases: ["what kind of video", "what can you edit", "do you edit", "what styles", "do you do"],
    concepts: { style: 2, platform: 2 },
    build: ({ u }) => ({
      text: `${
        u.concepts.has("style") || u.concepts.has("platform") ? "Yeah, that's right in my lane. " : ""
      }Vertical stuff mostly — TikToks, Reels, Shorts. Gaming clips, vlogs, podcast cuts, talking-head, montages.\n\nHooks, tight pacing, captions, color, sound mix. Whatever makes someone stop scrolling.`,
      chips: ["How much?", "What about longer videos?", "I'm ready"],
      nav: WORK,
    }),
  },

  {
    id: "longform",
    phrases: [
      "longer video", "long form", "horizontal", "16 9", "youtube video",
      "more than 10 minutes", "over 10 minutes", "full length",
    ],
    build: () => ({
      text: "The calculator tops out at 10 minutes because that covers basically everything vertical.\n\nLonger or horizontal stuff isn't off the table — it's just a different kind of job and I'd want to quote it properly rather than guess. Describe what you've got in the notes and you'll get a straight answer.",
      chips: ["What do you need from me?", "What's the normal rate?"],
    }),
  },

  {
    id: "software",
    phrases: [
      "what software", "what program", "premiere", "after effects", "capcut",
      "davinci", "final cut", "what do you use", "what editor",
    ],
    build: () => ({
      text: "Whatever the edit calls for — the tool matters way less than the result.\n\nIf you've got a specific style you're chasing, send a reference video. That tells me more than any software name would.",
      chips: ["See the work", "How much?"],
      nav: WORK,
    }),
  },

  {
    id: "music",
    phrases: [
      "what about music", "do you add music", "copyright music", "licensed music",
      "can you add sound", "sound effects", "trending sound",
    ],
    build: () => ({
      text: "Yep, music and sound design are part of the edit.\n\nIf you want a specific track or trending sound, tell me which one. If you leave it to me I'll pick something that fits the pacing. Just know that trending audio is on you to clear — platforms treat that differently depending on whether your account is personal or business.",
      chips: ["What else is included?", "How much?"],
    }),
  },

  {
    id: "captions",
    phrases: ["do you do captions", "add subtitles", "captions included", "text on screen"],
    build: () => ({
      text: "Captions are included, not an upsell. Same with color, transitions and sound mix — it's all just part of the edit.\n\nThe only add-on is Rush if you need it faster.",
      chips: ["What's the price?", "How fast?"],
    }),
  },

  {
    id: "examples",
    phrases: ["can i see", "show me your work", "any examples", "your portfolio", "see the work"],
    concepts: { quality: 1.5 },
    build: () => ({
      text: "There are three recent vertical cuts on the page you can play — tap the button below whenever you want to jump there.\n\nThere's more posted on the TikTok if you want the full feed.",
      chips: ["How much for something like that?", "How fast?"],
      nav: WORK,
    }),
  },

  {
    id: "payment",
    phrases: ["how do i pay", "do you take paypal", "payment method", "how does payment work", "when do i pay"],
    concepts: { payment: 2 },
    build: () => ({
      text: "CashApp only, and you pay *after* we've agreed on what you're getting — never upfront before that conversation.\n\nOnce it clears I start cutting.",
      chips: ["What's the price?", "What do you need from me?"],
    }),
  },

  {
    id: "revisions",
    phrases: ["what if i dont like", "can i get changes", "how many revisions", "if i want changes"],
    concepts: { revision: 2 },
    build: () => ({
      text: "Every video gets one free light revision — typo in a caption, a trim, swap the music, adjust the color.\n\nAfter that it's $3 for a moderate revision, meaning actually re-cutting sections. Most people never get that far.",
      chips: ["What's the price?", "I'm ready"],
    }),
  },

  {
    id: "trust",
    phrases: ["how do i know", "are you legit", "why should i", "is this real", "is this a scam", "what if you dont deliver"],
    concepts: { trust_doubt: 2 },
    build: () => ({
      text: "Good question, and you should be asking it.\n\nThe work's on this page so you can judge it yourself. 50+ videos out the door so far. And nothing leaves your account until we've agreed exactly what you're getting — no deposit, no subscription, no card on file.\n\nIf you're unsure, one video is the cheapest way to find out.",
      chips: ["Price for one video?", "What do you need from me?"],
      nav: WORK,
    }),
  },

  {
    id: "bulk",
    phrases: ["a bunch of videos", "every week", "how many can you do", "in bulk", "batch", "ongoing"],
    concepts: { quantity: 2 },
    build: ({ mem, ent }) => {
      const minutes = ent.minutes ?? mem.minutes ?? 0.5;
      const count = ent.count ?? mem.count ?? 5;
      return {
        text: `${priceLine(minutes, count)}\n\nSame flat rate per video whether it's one or twenty — no bulk surcharge. If you're posting regularly, batching a week's worth at a time is the easiest way to stay ahead.`,
        chips: ["How long would that take?", "What about 30 videos?"],
        nav: CALC,
      };
    },
  },

  {
    id: "ready",
    phrases: ["lets do it", "im ready", "i want to order", "sign me up", "lets go", "im in", "how do i book", "im sold", "take me there"],
    concepts: { commit: 2.5 },
    build: () => ({
      text: "Nice. Set your length and count in the calculator so the price reflects what you actually need, then hit **Send this estimate** — your numbers ride along into the form.\n\nYou'll hear back within 24 hours.",
      chips: ["What should I put in the notes?"],
      nav: CALC,
    }),
  },

  {
    id: "rights",
    phrases: ["who owns", "can i monetize", "usage rights", "do i own"],
    concepts: { ownership: 2 },
    build: () => ({
      text: "You own your footage and the finished edit outright. Post it, monetize it, run ads on it — no royalties, no strings.\n\nOnly thing I ask is being able to show finished cuts in my portfolio, and if you'd rather I didn't, just say so.",
      chips: ["What's the price?", "I'm ready"],
    }),
  },

  {
    id: "human",
    phrases: ["are you a bot", "talk to a human", "speak to someone", "is this a bot", "real person", "who am i talking to"],
    concepts: { person: 2, social: 2 },
    build: () => ({
      text: "I'm a bot, yeah — I just handle the common questions so you're not waiting on a reply for something simple.\n\nAnything real goes to the actual editor through the form. There's a \"Just want to talk\" option if you'd rather ask questions than order anything.",
      chips: ["Pricing", "Turnaround", "What do you need from me?"],
    }),
  },

  {
    id: "praise",
    phrases: ["thank you", "thats helpful", "appreciate it", "looks good", "thats fire", "youre helpful"],
    concepts: { praise: 1.5 },
    build: ({ n }) => ({
      text: variant(
        ["Appreciate that. Anything else on your mind?", "Anytime. What else can I clear up?"],
        n
      ),
      chips: ["How much?", "How fast?", "I'm ready"],
    }),
  },

  {
    id: "decline",
    phrases: ["nevermind", "not right now", "just looking", "maybe later", "ill think about it"],
    concepts: { decline: 2.5 },
    build: () => ({
      text: "All good, no pressure.\n\nHave a look at the work on your way out if you want — that way you know what's here when you do need it.",
      chips: ["Actually, how much?"],
      nav: WORK,
    }),
  },
];

// ---------- Off-topic steering ----------

function steer(kind: string, n: number): Reply {
  const map: Record<string, string[]> = {
    joke: ["Ha, alright — that got me.", "You're funny. I'm a chatbot for a video editor though, so my material's thin."],
    smalltalk: ["Ha, same energy honestly.", "I'd chat properly but I'm basically a very opinionated pricing sheet."],
    personal: ["I'm just the assistant — the editor's the one you'd actually be working with.", "Couldn't tell you. I only know editing and prices."],
    gametalk: ["Solid game. Funny enough that's most of what comes through here — gaming clips cut down for TikTok.", "Nice. Gaming edits are probably half of what I see."],
    competitor: ["Sure, there are cheaper options out there — some of them are fine.", "Fair, there's no shortage of editors around."],
    unrelated: ["That's outside my department, I'm afraid.", "Way out of my lane on that one."],
  };
  return {
    text: `${variant(map[kind] ?? map.unrelated, n)}\n\n${bridge(n)}`,
    chips: ["How much does it cost?", "How fast?", "See the work"],
  };
}

// ---------- Matching ----------

const FLOOR = 1.8;

export function respond(
  raw: string,
  memory: ChatMemory
): { reply: Reply; memory: ChatMemory } {
  const norm = normalize(raw);
  const u = understand(norm);
  const ent = extractEntities(raw);

  const mem: ChatMemory = {
    ...memory,
    turns: memory.turns + 1,
    minutes: ent.minutes ?? memory.minutes,
    count: ent.count ?? memory.count,
    hits: { ...memory.hits },
    seen: [...memory.seen],
  };

  let best: Intent | null = null;
  let bestScore = 0;

  for (const intent of INTENTS) {
    let score = 0;
    for (const p of intent.phrases ?? []) if (norm.includes(p)) score += 4;
    for (const [c, w] of Object.entries(intent.concepts ?? {})) {
      const got = u.concepts.get(c as Concept);
      if (got) score += Math.min(got, 3) * (w as number) * 0.8;
    }
    if (score > bestScore) {
      bestScore = score;
      best = intent;
    }
  }

  // Asking about a count bigger than the slider allows is a limits question
  const want = ent.count ?? mem.count;
  const mins = ent.minutes ?? mem.minutes ?? 0.5;
  if (want && want > maxVideosFor(mins) && bestScore < 4) {
    best = INTENTS.find((i) => i.id === "limits")!;
    bestScore = 4;
  }

  if ((!best || bestScore < FLOOR) && (ent.minutes || ent.count)) {
    best = INTENTS.find((i) => i.id === "price")!;
    bestScore = FLOOR;
  }

  if (best && bestScore >= FLOOR) {
    const n = mem.hits[best.id] ?? 0;
    mem.hits[best.id] = n + 1;
    mem.lastIntent = best.id;
    mem.misses = 0;
    if (!mem.seen.includes(best.id)) mem.seen.push(best.id);
    return { reply: best.build({ mem, ent, u, n }), memory: mem };
  }

  if (u.offTopic) {
    const key = `ot_${u.offTopic}`;
    const n = mem.hits[key] ?? 0;
    mem.hits[key] = n + 1;
    mem.lastIntent = "offtopic";
    mem.misses = 0;
    return { reply: steer(u.offTopic, n), memory: mem };
  }

  mem.misses = memory.lastIntent === "fallback" ? memory.misses + 1 : 1;
  mem.lastIntent = "fallback";
  return { reply: fallback(mem, u), memory: mem };
}

function fallback(m: ChatMemory, u: Understanding): Reply {
  if (m.misses >= 3) {
    return {
      text: "I'm clearly not the right tool for this one — my fault, not yours.\n\nWrite it in the notes box on the form and the actual editor will get back to you within a day.",
      chips: ["Pricing", "Turnaround"],
      nav: CALC,
    };
  }

  if (u.tone < 0) {
    return {
      text: "Sounds like something's bugging you about this. Tell me which part and I'll give it to you straight — the price, the timing, or how the whole thing works?",
      chips: ["Pricing", "Turnaround", "How it works"],
    };
  }

  const menu = [
    ["Pricing", "price"],
    ["Turnaround", "speed"],
    ["What to send me", "process"],
    ["Revisions", "revisions"],
  ] as const;
  const fresh = menu.filter(([, id]) => !m.seen.includes(id)).map(([l]) => l);

  return {
    text: variant(
      [
        "Hm, not sure I followed that. I'm good on pricing, timing, what I need from you, and revisions — any of those?",
        "That one went over my head, sorry. Try me on price, speed, or how to get started.",
      ],
      m.misses - 1
    ),
    chips: (fresh.length ? fresh : menu.map(([l]) => l)).slice(0, 4),
  };
}

export const GREETING: Reply = {
  text: "Hey — I'm the assistant for RuthlessKillYT. He edits vertical video: TikToks, Reels, Shorts, gaming clips.\n\nAsk me whatever — pricing, turnaround, what he needs from you. I'll give you real numbers.",
  chips: ["How much does it cost?", "How fast is delivery?", "Can I see the work?"],
};
