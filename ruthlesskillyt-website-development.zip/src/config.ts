// ============================================================
//  RUTHLESSKILLYT — SITE CONFIG
//  Everything you're likely to change lives in this one file.
// ============================================================

// ---------- Brand ----------
export const BRAND = {
  name: "RuthlessKillYT",
  cashappTag: "$itscwmoney",
  tiktokHandle: "@ruthlesskillyt",
  tiktokUrl: "https://www.tiktok.com/@ruthlesskillyt",
  websiteUrl: "https://RuthlesskillYT.my.canva.site",
};

// ---------- Pricing ----------
// One flat rate: $7.50 per finished minute — $3.75 for a 30-second cut.
// Every video, no hourly billing, ever.
export const FLAT_RATE = 7.5;

// Entry price shown in copy (a 30-second video).
export const HALF_MIN_RATE = FLAT_RATE / 2;

// Add-ons are priced PER VIDEO, get cheaper on shorter videos, and scale
// up with length only as the job actually gets bigger.
// Every curve returns a whole dollar amount at 0.5-minute steps.
export const ADD_ONS = [
  {
    id: "rush",
    name: "Rush 24–72h",
    desc: "Jump the queue — your edits land in 24 to 72 hours instead of 3–7 days.",
    // Scales with the $7.50/min base: ~50% of the edit on short clips,
    // tapering to ~20% on the longest ones.
    // 30s $2 · 1m $4 · 2m $5 · 3m $6 · 5m $8 · 10m $15
    priceFor: (minutes: number) =>
      minutes < 1 ? 2 : Math.max(4, Math.ceil(1.5 * minutes)),
  },
] as const;

export type AddOnId = (typeof ADD_ONS)[number]["id"];

export function addOnPricePerVideo(id: AddOnId, minutes: number): number {
  return ADD_ONS.find((a) => a.id === id)?.priceFor(minutes) ?? 0;
}

// ---------- Calculator logic ----------
// Single source of truth for the estimate — the calculator, the contact
// form summary and the EmailJS payload all read from this. No drift.
export type EstimateState = {
  minutes: number; // length of ONE video
  count: number; // how many videos
  addOns: AddOnId[];
  total: number;
};

export const MIN_MINUTES = 0.5;
export const MAX_MINUTES = 10;
export const MAX_VIDEOS = 20;

// How many videos of a given length it makes sense to book in one order —
// short clips can bundle big packs; a 10-minute edit is a bigger job,
// so the pack size shrinks. This is what keeps the count bar honest.
export function maxVideosFor(minutes: number): number {
  return Math.min(MAX_VIDEOS, Math.max(1, Math.ceil(20 / minutes)));
}

export function computeTotal(
  minutes: number,
  count: number,
  addOns: AddOnId[]
): number {
  const editCost = minutes * count * FLAT_RATE; // flat rate — always
  const addOnCost = addOns.reduce(
    (sum, id) => sum + addOnPricePerVideo(id, minutes) * count,
    0
  );
  return round(editCost + addOnCost);
}

export function round(n: number): number {
  return Math.round(n * 100) / 100;
}

export function formatMinutes(minutes: number): string {
  if (minutes < 1) return `${Math.round(minutes * 60)} sec`;
  return `${minutes % 1 === 0 ? minutes : minutes.toFixed(1)} min`;
}

export function formatMoney(n: number): string {
  return "$" + n.toFixed(2).replace(/\.00$/, "");
}

// ---------- Showcase shells ----------
// Google Drive videos. `embedUrl` plays the file in Drive's own player,
// `poster` pulls a real frame straight out of the uploaded video via
// Drive's thumbnail endpoint (works once the file is link-shared).
const driveEmbed = (id: string) =>
  `https://drive.google.com/file/d/${id}/preview`;
const driveThumb = (id: string) =>
  `https://drive.google.com/thumbnail?id=${id}&sz=w1000`;

export const SHOWCASE = [
  {
    title: "Edit 1",
    style: "Vertical",
    length: "0:30",
    embedUrl: driveEmbed("1deXOfoW_i2aCQrSt1o7VkRRpWqkhTVdw"),
    poster: driveThumb("1deXOfoW_i2aCQrSt1o7VkRRpWqkhTVdw"),
  },
  {
    title: "Edit 2",
    style: "Vertical",
    length: "0:30",
    embedUrl: driveEmbed("1nprW9Y4JHSYQR40N0kVF8W0K6aJoJ6sa"),
    poster: driveThumb("1nprW9Y4JHSYQR40N0kVF8W0K6aJoJ6sa"),
  },
  {
    title: "Edit 3",
    style: "Vertical",
    length: "0:30",
    embedUrl: driveEmbed("1q3QtHRXqJtoX6_K8aJWQh6nrSipNNxhn"),
    poster: driveThumb("1q3QtHRXqJtoX6_K8aJWQh6nrSipNNxhn"),
  },
];

// ---------- EmailJS ----------
// 1. Create a free account at https://www.emailjs.com
// 2. Email Services  -> connect your inbox  -> copy the SERVICE ID
// 3. Email Templates -> create a template    -> copy the TEMPLATE ID
// 4. Account -> API Keys                      -> copy the PUBLIC KEY
//
// Template variables this site sends (put these in your EmailJS template):
//   {{from_name}}     sender's name
//   {{from_email}}    sender's email
//   {{reply_to}}      same as from_email (just hit Reply in your inbox)
//   {{mode}}          "Edit Request" or "Just Want To Talk"
//   {{video_length}}  length of ONE video, e.g. "2 min"  (edit requests only)
//   {{video_count}}   number of videos, e.g. "3"         (edit requests only)
//   {{add_ons}}       selected add-ons, e.g. "Rush 24–72h" or "None" (edit requests only)
//   {{estimate}}      quoted total, e.g. "$25"           (edit requests only)
//   {{cashapp_tag}}   sender's CashApp $tag              (optional field)
//   {{notes}}         project notes / message
//
// "Just Want To Talk" emails intentionally exclude video_length,
// video_count, add_ons and estimate so no leftover project data leaks in.
export const EMAILJS = {
  serviceId: "service_v1zi6km",
  templateId: "template_g8qtg6h",
  publicKey: "5KZoOkrHW_p8dANKT",
};

export const EMAILJS_READY =
  EMAILJS.serviceId !== "service_placeholder" &&
  EMAILJS.templateId !== "template_placeholder" &&
  EMAILJS.publicKey !== "public_key_placeholder";
