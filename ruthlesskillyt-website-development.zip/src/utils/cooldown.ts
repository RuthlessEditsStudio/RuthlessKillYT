// 24-hour cooldown utility — prevents rapid re-submissions on the same device.
// Uses localStorage so the timer survives page reloads and browser restarts.
//
// IMPORTANT: every localStorage call is wrapped. Safari Private Browsing,
// iOS webviews (TikTok/Instagram in-app browsers) and blocked-cookie setups
// THROW on localStorage access. Unguarded, that crashes the whole page —
// and most of this site's traffic comes from in-app browsers.

const STORAGE_KEY = "ruthlessKillYT_lastSubmission";
const COOLDOWN_MS = 24 * 60 * 60 * 1000; // 24 hours

/** In-memory fallback used when localStorage is unavailable. */
let memoryFallback: number | null = null;

function readStamp(): number | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw !== null) {
      const n = Number(raw);
      // Ignore corrupted / tampered values
      if (Number.isFinite(n) && n > 0 && n <= Date.now()) return n;
      return null;
    }
  } catch {
    /* storage blocked — fall through to memory */
  }
  return memoryFallback;
}

function writeStamp(value: number): void {
  memoryFallback = value;
  try {
    localStorage.setItem(STORAGE_KEY, String(value));
  } catch {
    /* storage blocked — memory fallback still holds for this session */
  }
}

export function isOnCooldown(): boolean {
  const last = readStamp();
  if (last === null) return false;
  return Date.now() - last < COOLDOWN_MS;
}

export function getRemainingMs(): number {
  const last = readStamp();
  if (last === null) return 0;
  return Math.max(0, COOLDOWN_MS - (Date.now() - last));
}

export function formatRemaining(ms: number): string {
  if (ms <= 0) return "a moment";
  const hours = Math.floor(ms / (1000 * 60 * 60));
  const mins = Math.floor((ms % (1000 * 60 * 60)) / (1000 * 60));
  const secs = Math.floor((ms % (1000 * 60)) / 1000);
  if (hours > 0) return `${hours}h ${mins}m`;
  if (mins > 0) return `${mins}m ${secs}s`;
  return `${secs}s`;
}

export function recordSubmission(): void {
  writeStamp(Date.now());
}

export function clearCooldown(): void {
  memoryFallback = null;
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch {
    /* nothing to do */
  }
}
